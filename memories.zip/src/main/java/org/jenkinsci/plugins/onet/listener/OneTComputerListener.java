package org.jenkinsci.plugins.onet.listener;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang.StringUtils;
import org.jenkinsci.plugins.onet.configuration.OneTConfiguration;
import org.jenkinsci.plugins.onet.cron.CronTab;

import hudson.Extension;
import hudson.model.Computer;
import hudson.model.TaskListener;
import hudson.slaves.ComputerListener;


@Extension
public class OneTComputerListener extends ComputerListener
{
	
	/** The logger. */
	private static Logger LOGGER = Logger.getLogger(ComputerListener.class.getName());

	/* (non-Javadoc)
	 * @see hudson.slaves.ComputerListener#onOnline(hudson.model.Computer, hudson.model.TaskListener)
	 */
	@Override
    public void onOnline(Computer c, TaskListener listener) throws IOException, InterruptedException {  
				
		if(StringUtils.isNotBlank(OneTConfiguration.DESCRIPTOR.cron)) {	
			
			LOGGER.log(Level.FINEST, "Starting CRON with schedule: " + OneTConfiguration.DESCRIPTOR.cron);
			
			CronTab.runCronJob(OneTConfiguration.DESCRIPTOR.cron);
		}
		else
			LOGGER.log(Level.FINEST, "CRON not started, value is blank");
    }
}
