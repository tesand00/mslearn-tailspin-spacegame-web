package org.jenkinsci.plugins.onet.workspace;

import org.kohsuke.stapler.DataBoundConstructor;

// TODO: Auto-generated Javadoc
/**
 * The Class WorkspaceFile.
 */
public class WorkspaceFile {
	
	/**
	 * Instantiates a new workspace file.
	 *
	 * @param buildVariable the build variable
	 * @param filePath the file path
	 */
	@DataBoundConstructor
	public WorkspaceFile(String buildVariable, String filePath) { 
		
		this.buildVariable = buildVariable;
		this.filePath = filePath;
    }
	
	/** The build variable. */
	public String buildVariable;			
	
	/** The file path. */
	public String filePath;	
}
