package org.jenkinsci.plugins.onet.model;

import java.io.Serializable;

// TODO: Auto-generated Javadoc
/**
 * The Class ResponseValue.
 */
public class ResponseValue implements Serializable {
	
	/** The response code. */
	private int responseCode;
	
	/** The content. */
	private String content;

	/**
	 * Gets the response code.
	 *
	 * @return the response code
	 */
	public int getResponseCode()
	{
		return responseCode;
	}

	/**
	 * Sets the response code.
	 *
	 * @param responseCode the new response code
	 */
	public void setResponseCode(int responseCode)
	{
		this.responseCode = responseCode;
	}

	/**
	 * Gets the content.
	 *
	 * @return the content
	 */
	public String getContent()
	{
		return content;
	}

	/**
	 * Sets the content.
	 *
	 * @param content the new content
	 */
	public void setContent(String content)
	{
		this.content = content;
	}	

}
