package org.jenkinsci.plugins.onet.model;

import java.io.Serializable;

// TODO: Auto-generated Javadoc
/**
 * The Class BuildData.
 */
public class Body implements Serializable
{		
	
	/** The eventdata. */
	private EventData eventdata;
	
	/** The realtime. */
	private boolean realtime;

	/**
	 * Gets the eventdata.
	 *
	 * @return the eventdata
	 */
	public EventData getEventdata() {
		return eventdata;
	}

	/**
	 * Sets the eventdata.
	 *
	 * @param eventdata the new eventdata
	 */
	public void setEventdata(EventData eventdata) {
		this.eventdata = eventdata;
	}

	/**
	 * Checks if is realtime.
	 *
	 * @return true, if is realtime
	 */
	public boolean isRealtime() {
		return realtime;
	}

	/**
	 * Sets the realtime.
	 *
	 * @param realtime the new realtime
	 */
	public void setRealtime(boolean realtime) {
		this.realtime = realtime;
	}
	
	
	
}