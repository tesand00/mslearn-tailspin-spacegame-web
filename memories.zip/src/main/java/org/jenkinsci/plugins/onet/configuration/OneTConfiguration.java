package org.jenkinsci.plugins.onet.configuration;

import java.util.List;
import java.util.logging.Logger;

import org.apache.commons.lang.StringUtils;
import org.jenkinsci.plugins.onet.constants.OneTConstants;
import org.jenkinsci.plugins.onet.cron.CronTab;
import org.jenkinsci.plugins.onet.processor.BackupProcessor;
import org.jenkinsci.plugins.onet.workspace.ConsoleButton;
import org.jenkinsci.plugins.onet.workspace.WorkspaceFile;
import org.kohsuke.stapler.StaplerRequest;

import com.cloudbees.plugins.credentials.common.StandardListBoxModel;
import com.cloudbees.plugins.credentials.impl.UsernamePasswordCredentialsImpl;

import hudson.Extension;
import hudson.model.AbstractProject;
import hudson.model.JobProperty;
import hudson.model.JobPropertyDescriptor;
import hudson.security.ACL;
import hudson.util.FormValidation;
import hudson.util.ListBoxModel;
import jenkins.model.Jenkins;
import net.sf.json.JSONObject;


// TODO: Auto-generated Javadoc
/**
 * The Class OneTConfiguration.
 */
public class OneTConfiguration extends JobProperty<AbstractProject<?, ?>> {
	
	/** The logger. */
	private static Logger LOGGER = Logger.getLogger(OneTConfiguration.class.getName());
	
	/** The Constant DESCRIPTOR. */
	@Extension
	public static final OneTConfigurationDescriptor DESCRIPTOR = new OneTConfigurationDescriptor();	
	
	/**
	 * The Class OneTConfigurationDescriptor.
	 */
	public static class OneTConfigurationDescriptor extends JobPropertyDescriptor {
		
		/** The host. */
		public String host;
		
		/** The url. */
		public String url;
		
		/** The proxy host. */
		public String proxyHost;
		
		/** The identifier url. */
		public String identifierUrl;
		
		/** The identifier authorization string. */
		public String identifierAuthorizationString;
		
		/** The identifier proxy host. */
		public String identifierProxyHost;
		
		/** The identifier proxy port. */
		public int identifierProxyPort;
		
		/** The credentials Id. */		
		public String credentialsId; 
		
		/** The cron. */
		public String cron;	
		
		/** The max backup jobs. */
		public int maxBackupJobs;
		
		/** The max log size. */
		public int maxLogSize;
		
		/** The timeout. */
		public int timeout;
		
		/** The checksum filter. */
		public String checksumFilter;
		
		/** The realtime. */
		public boolean realtime;
		
		/** The enabled. */
		public boolean enabled;
		
		/** The identifier. */
		public boolean identifier;
		
		/** The conversation id. */
		public boolean conversationId;
				
		/** The mail SMTP host. */
		public String mailSMTPHost;
		
		/** The mail to. */
		public String mailTo;
		
		/** The mail from. */
		public String mailFrom;
		
		/** The mail message. */
		public String mailMessage;
		
		/** The workspace files. */
		public List<WorkspaceFile> workspaceFiles;	
		
		/** The console links. */
		public List<ConsoleButton> consoleButtons;
		
		/**
		 * Gets the host.
		 *
		 * @return the host
		 */
		public String getHost() {
			return host;
		}

		/**
		 * Sets the host.
		 *
		 * @param host the new host
		 */
		public void setHost(String host) {
			this.host = host;
		}

		/**
		 * Gets the url.
		 *
		 * @return the url
		 */
		public String getUrl() {
			return url;
		}

		/**
		 * Sets the url.
		 *
		 * @param url the new url
		 */
		public void setUrl(String url) {
			this.url = url;
		}		

		/**
		 * Gets the proxy host.
		 *
		 * @return the proxy host
		 */
		public String getProxyHost() {
			return proxyHost;
		}

		/**
		 * Sets the proxy host.
		 *
		 * @param proxyHost the new proxy host
		 */
		public void setProxyHost(String proxyHost) {
			this.proxyHost = proxyHost;
		}
		
		/**
		 * Gets the identifier url.
		 *
		 * @return the identifier url
		 */
		public String getIdentifierUrl() {
			return identifierUrl;
		}

		/**
		 * Sets the identifier url.
		 *
		 * @param identifierUrl the new identifier url
		 */
		public void setIdentifierUrl(String identifierUrl) {
			this.identifierUrl = identifierUrl;
		}

		/**
		 * Gets the identifier authorization string.
		 *
		 * @return the identifier authorization string
		 */
		public String getIdentifierAuthorizationString() {
			return identifierAuthorizationString;
		}

		/**
		 * Sets the identifier authorization string.
		 *
		 * @param identifierAuthorizationString the new identifier authorization string
		 */
		public void setIdentifierAuthorizationString(String identifierAuthorizationString) {
			this.identifierAuthorizationString = identifierAuthorizationString;
		}

		/**
		 * Gets the identifier proxy host.
		 *
		 * @return the identifier proxy host
		 */
		public String getIdentifierProxyHost() {
			return identifierProxyHost;
		}

		/**
		 * Sets the identifier proxy host.
		 *
		 * @param identifierProxyHost the new identifier proxy host
		 */
		public void setIdentifierProxyHost(String identifierProxyHost) {
			this.identifierProxyHost = identifierProxyHost;
		}

		/**
		 * Gets the identifier proxy port.
		 *
		 * @return the identifier proxy port
		 */
		public int getIdentifierProxyPort() {
			return identifierProxyPort;
		}

		/**
		 * Sets the identifier proxy port.
		 *
		 * @param identifierProxyPort the new identifier proxy port
		 */
		public void setIdentifierProxyPort(int identifierProxyPort) {
			this.identifierProxyPort = identifierProxyPort;
		}

		/**
		 * Gets the credentials id.
		 *
		 * @return the credentials id
		 */
		public String getCredentialsId() {
			return credentialsId;
		}

		/**
		 * Sets the credentials id.
		 *
		 * @param credentialsId the new credentials id
		 */
		public void setCredentialsId(String credentialsId) {
			this.credentialsId = credentialsId;
		}

		/**
		 * Gets the cron.
		 *
		 * @return the cron
		 */
		public String getCron() {
			return cron;
		}

		/**
		 * Sets the cron.
		 *
		 * @param cron the new cron
		 */
		public void setCron(String cron) {
			this.cron = cron;
		}

		/**
		 * Gets the max backup jobs.
		 *
		 * @return the max backup jobs
		 */
		public int getMaxBackupJobs() {
			return maxBackupJobs;
		}

		/**
		 * Sets the max backup jobs.
		 *
		 * @param maxBackupJobs the new max backup jobs
		 */
		public void setMaxBackupJobs(int maxBackupJobs) {
			this.maxBackupJobs = maxBackupJobs;
		}

		/**
		 * Gets the max log size.
		 *
		 * @return the max log size
		 */
		public int getMaxLogSize() {
			return maxLogSize;
		}

		/**
		 * Sets the max log size.
		 *
		 * @param maxLogSize the new max log size
		 */
		public void setMaxLogSize(int maxLogSize) {
			this.maxLogSize = maxLogSize;
		}		

		/**
		 * Gets the timeout.
		 *
		 * @return the timeout
		 */
		public int getTimeout() {
			return timeout;
		}

		/**
		 * Sets the timeout.
		 *
		 * @param timeout the new timeout
		 */
		public void setTimeout(int timeout) {
			this.timeout = timeout;
		}		

		/**
		 * Gets the checksum filter.
		 *
		 * @return the checksum filter
		 */
		public String getChecksumFilter() {
			return checksumFilter;
		}

		/**
		 * Sets the checksum filter.
		 *
		 * @param checksumFilter the new checksum filter
		 */
		public void setChecksumFilter(String checksumFilter) {
			this.checksumFilter = checksumFilter;
		}

		/**
		 * Checks if is enabled.
		 *
		 * @return true, if is enabled
		 */
		public boolean isEnabled() {
			return enabled;
		}

		/**
		 * Sets the enabled.
		 *
		 * @param enabled the new enabled
		 */
		public void setEnabled(boolean enabled) {
			this.enabled = enabled;
		}		

		/**
		 * Checks if is realtime.
		 *
		 * @return true, if is realtime
		 */
		public boolean isRealtime() {
			return realtime;
		}

		/**
		 * Sets the realtime.
		 *
		 * @param realtime the new realtime
		 */
		public void setRealtime(boolean realtime) {
			this.realtime = realtime;
		}		

		/**
		 * Checks if is identifier.
		 *
		 * @return true, if is identifier
		 */
		public boolean isIdentifier() {
			return identifier;
		}

		/**
		 * Sets the identifier.
		 *
		 * @param identifier the new identifier
		 */
		public void setIdentifier(boolean identifier) {
			this.identifier = identifier;
		}

		/**
		 * Checks if is conversation id.
		 *
		 * @return true, if is conversation id
		 */
		public boolean isConversationId() {
			return conversationId;
		}

		/**
		 * Sets the conversation id.
		 *
		 * @param conversationId the new conversation id
		 */
		public void setConversationId(boolean conversationId) {
			this.conversationId = conversationId;
		}

		/**
		 * Gets the mail SMTP host.
		 *
		 * @return the mail SMTP host
		 */
		public String getMailSMTPHost() {
			return mailSMTPHost;
		}

		/**
		 * Sets the mail SMTP host.
		 *
		 * @param mailSMTPHost the new mail SMTP host
		 */
		public void setMailSMTPHost(String mailSMTPHost) {
			this.mailSMTPHost = mailSMTPHost;
		}

		/**
		 * Gets the mail to.
		 *
		 * @return the mail to
		 */
		public String getMailTo() {
			return mailTo;
		}

		/**
		 * Sets the mail to.
		 *
		 * @param mailTo the new mail to
		 */
		public void setMailTo(String mailTo) {
			this.mailTo = mailTo;
		}

		/**
		 * Gets the mail from.
		 *
		 * @return the mail from
		 */
		public String getMailFrom() {
			return mailFrom;
		}

		/**
		 * Sets the mail from.
		 *
		 * @param mailFrom the new mail from
		 */
		public void setMailFrom(String mailFrom) {
			this.mailFrom = mailFrom;
		}

		/**
		 * Gets the mail message.
		 *
		 * @return the mail message
		 */
		public String getMailMessage() {
			return mailMessage;
		}

		/**
		 * Sets the mail message.
		 *
		 * @param mailMessage the new mail message
		 */
		public void setMailMessage(String mailMessage) {
			this.mailMessage = mailMessage;
		}

		/**
		 * Gets the workspace files.
		 *
		 * @return the workspace files
		 */
		public List<WorkspaceFile> getWorkspaceFiles() {
			return workspaceFiles;
		}

		/**
		 * Sets the workspace files.
		 *
		 * @param workspaceFiles the new workspace files
		 */
		public void setWorkspaceFiles(List<WorkspaceFile> workspaceFiles) {
			this.workspaceFiles = workspaceFiles;
		}
		
		/**
		 * Gets the console buttons.
		 *
		 * @return the console buttons
		 */
		public List<ConsoleButton> getConsoleButtons() {
			return consoleButtons;
		}
		
		/**
		 * Sets the console buttons.
		 *
		 * @param consoleButtons the new console buttons
		 */
		public void setConsoleButtons(List<ConsoleButton> consoleButtons) {
			this.consoleButtons = consoleButtons;
		}

		/**
		 * Do fill credentials id items.
		 *
		 * @param credentialsId the credentials id
		 * @return the list box model
		 */
		public static ListBoxModel doFillCredentialsIdItems(String credentialsId) { 
			
			if (credentialsId == null)  
				credentialsId = ""; 
			 
			if (!Jenkins.get().hasPermission(Jenkins.ADMINISTER)) 			        	 
				return new StandardListBoxModel().includeCurrentValue(credentialsId);			
			         
			return new StandardListBoxModel().includeEmptyValue().includeAs(ACL.SYSTEM, Jenkins.get(),UsernamePasswordCredentialsImpl.class).includeCurrentValue(credentialsId); 
		}
		
		/**
		 * Do run backup.
		 *
		 * @return the form validation
		 */
		public FormValidation doRunBackup()	{	
			
			if(BackupProcessor.uploadBuilds())
				return FormValidation.ok(OneTConstants.MESSAGE_BACKUP_SUCCESSFUL);
			else
				return FormValidation.warning(OneTConstants.MESSAGE_BACKUP_UNSUCCESSFUL);
		}
		

		/**
		 * Instantiates a new one T configuration descriptor.
		 */
		public OneTConfigurationDescriptor() {
			
			super(OneTConfiguration.class); 
			
			load();
		}
		
		/**
		 * Gets the display name.
		 *
		 * @return the display name
		 */
		/* (non-Javadoc)
		 * @see hudson.model.Descriptor#getDisplayName()
		 */
		@Override
		public String getDisplayName() {
			
			return OneTConstants.ONET_NAME;
		}
		
		/**
		 * Configure.
		 *
		 * @param req the req
		 * @param json the json
		 * @return true, if successful
		 * @throws FormException the form exception
		 */
		/* (non-Javadoc)
		 * @see hudson.model.Descriptor#configure(org.kohsuke.stapler.StaplerRequest, net.sf.json.JSONObject)
		 */
		@Override
        public boolean configure(StaplerRequest req, JSONObject json) throws FormException {  			
			
            req.bindJSON(this,json);
            
            save();
            
            if(StringUtils.isNotBlank(OneTConfiguration.DESCRIPTOR.cron))
            	CronTab.runCronJob(OneTConfiguration.DESCRIPTOR.cron);           
            
            return true;            
        }	
		
	}
	

}

