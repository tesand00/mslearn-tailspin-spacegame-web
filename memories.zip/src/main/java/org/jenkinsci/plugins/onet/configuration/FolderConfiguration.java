package org.jenkinsci.plugins.onet.configuration;

import java.util.List;
import java.util.logging.Logger;

import org.jenkinsci.plugins.onet.constants.OneTConstants;
import org.jenkinsci.plugins.onet.workspace.WorkspaceFile;
import org.kohsuke.stapler.DataBoundConstructor;
import org.kohsuke.stapler.StaplerRequest;

import com.cloudbees.hudson.plugins.folder.AbstractFolder;
import com.cloudbees.hudson.plugins.folder.AbstractFolderProperty;
import com.cloudbees.hudson.plugins.folder.AbstractFolderPropertyDescriptor;

import hudson.Extension;
import hudson.model.Descriptor.FormException;
import net.sf.json.JSONObject;

public class FolderConfiguration extends AbstractFolderProperty<AbstractFolder<?>> {

	 @DataBoundConstructor
	 public FolderConfiguration() {
		 
	 }
	
	 private static Logger LOGGER = Logger.getLogger(FolderConfiguration.class.getName());
	 
	 public List<WorkspaceFile> workspaceFiles;	 

	 public List<WorkspaceFile> getWorkspaceFiles() {
			return workspaceFiles;
	 }
 
	 public void setFolderFiles(List<WorkspaceFile> workspaceFiles) {
		this.workspaceFiles = workspaceFiles;
	 }
	 
	 @Override
     public AbstractFolderProperty<?> reconfigure(StaplerRequest request, JSONObject form) throws FormException {
		 
        if (form == null)        	
            return null; 
      
        workspaceFiles = request.bindJSONToList(WorkspaceFile.class, form.get("workspaceFiles"));               
        
        return this;	        
	 }   
	 
	 @Extension
	 public static class DescriptorImpl extends AbstractFolderPropertyDescriptor {

	     @Override
	     public String getDisplayName() {
			 
			 return OneTConstants.ONET_TITLE;
	     }

	 }
}
