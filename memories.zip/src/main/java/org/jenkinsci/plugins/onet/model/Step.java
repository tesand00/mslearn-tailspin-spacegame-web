package org.jenkinsci.plugins.onet.model;

import java.io.Serializable;

// TODO: Auto-generated Javadoc
/**
 * The Class Step.
 */
public class Step implements Serializable {

	/** The name. */
	private String name;
	
	/** The log. */
	private String log;
	
	/** The status. */
	private String status;

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the log.
	 *
	 * @return the log
	 */
	public String getLog() {
		return log;
	}

	/**
	 * Sets the log.
	 *
	 * @param log the new log
	 */
	public void setLog(String log) {
		this.log = log;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}	
}
