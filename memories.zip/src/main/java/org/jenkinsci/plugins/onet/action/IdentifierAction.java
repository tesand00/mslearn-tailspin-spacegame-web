package org.jenkinsci.plugins.onet.action;

import hudson.model.Action;

public class IdentifierAction implements Action {
	
	private String ID;
	
	public IdentifierAction(String ID) {
		
		this.ID = ID;
	}
	
	public String getID() {
		return ID;
	}

	public void setID(String ID) {
		this.ID = ID;
	}

	@Override
	public String getIconFileName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getDisplayName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getUrlName() {
		// TODO Auto-generated method stub
		return null;
	}
}
