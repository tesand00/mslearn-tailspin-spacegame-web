package org.jenkinsci.plugins.onet.helper;

import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.jenkinsci.plugins.onet.util.CommonUtil;


// TODO: Auto-generated Javadoc
/**
 * The Class EmailHelper.
 */
public class EmailHelper 
{
	
	/** The logger. */
	private static Logger LOGGER = Logger.getLogger(EmailHelper.class.getName());
	
	/**
	 * Send mail.
	 *
	 * @param smtpHost the smtp host
	 * @param toGroup the to group
	 * @param from the from
	 * @param subject the subject
	 * @param content the content
	 */
	public static void sendMail(String smtpHost, String toGroup, String from, String subject, String content)
	{
	      Properties properties = System.getProperties();

	      properties.setProperty("mail.smtp.host", smtpHost);

	      Session session = Session.getDefaultInstance(properties);
	      
	      for(String recipient : toGroup.split(",")) {
	    	  
	    	  try {
	    		  
		         MimeMessage message = new MimeMessage(session);

		         message.setFrom(new InternetAddress(from));

		         message.addRecipient(Message.RecipientType.TO, new InternetAddress(recipient.trim()));

		         message.setSubject(subject);

		         message.setContent(CommonUtil.resolveVariables(content, null),"text/html");

		         Transport.send(message);
		         
		         LOGGER.log(Level.FINE, "Sent message successfully to " + recipient.trim());
		      }
		      catch(MessagingException e) {
		    	  
		    	  LOGGER.log(Level.SEVERE, e.toString());
		      }
	      }
	      
	      CommonUtil.nullifyQuietly(properties, session);
	}
}
