package org.jenkinsci.plugins.onet.processor;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.jenkinsci.plugins.onet.configuration.OneTConfiguration;
import org.jenkinsci.plugins.onet.constants.OneTConstants;
import org.jenkinsci.plugins.onet.helper.EmailHelper;
import org.jenkinsci.plugins.onet.model.OneTRequest;
import org.jenkinsci.plugins.onet.model.ResponseValue;
import org.jenkinsci.plugins.onet.util.CommonUtil;
import org.jenkinsci.plugins.onet.util.StringBuilderUtil;

import com.fasterxml.jackson.databind.ObjectMapper;

import jenkins.model.Jenkins;

// TODO: Auto-generated Javadoc
/**
 * The Class BackupProcessor.
 */
public class BackupProcessor
{
	
	/** The logger. */
	private static Logger LOGGER = Logger.getLogger(BackupProcessor.class.getName());		
	
	/**
	 * Upload builds.
	 *
	 * @return the string
	 */
	public static boolean uploadBuilds()
	{
		boolean success = true;
		
		int uploadCounterAttempted = 0;
		int uploadCounterSuccess = 0;
		int uploadCounterFailure = 0;
		
		ResponseValue responseValue = new ResponseValue();	
		File backupDirectory = new File(Jenkins.getInstanceOrNull().getRootDir() + OneTConstants.BACKUP_BUILD_DIRECTORY);
		StringBuilderUtil stringBuilder = new StringBuilderUtil();
		StringBuilder responseContent = new StringBuilder();
		ObjectMapper objectMapper = new ObjectMapper();
		
		stringBuilder.appendLine(OneTConstants.MESSAGE_BUILD_CHECKING_UPLOAD);
		
		if(backupDirectory.exists()) {
			
			stringBuilder.appendLine(OneTConstants.MESSAGE_NUMBER_BACKED_UP_JOBS + backupDirectory.listFiles().length);
			
			APIProcessor apiProcessor = new APIProcessor();
			
			for(File file : backupDirectory.listFiles()) {	
				
				if(uploadCounterAttempted < OneTConfiguration.DESCRIPTOR.maxBackupJobs) {					
										
					try	{
						
						if(CommonUtil.checkConfiguration()) {	
							
							boolean successfulPost = false;
							
							List<String> hostList = Arrays.asList(OneTConfiguration.DESCRIPTOR.host.split(","));
							
							Collections.shuffle(hostList);					
							
							for(String host : hostList) { 
								
								if(StringUtils.isNotEmpty(OneTConfiguration.DESCRIPTOR.proxyHost)) {
									
									responseValue = apiProcessor.postJson(host.split(":")[0], 
				   							  Integer.parseInt(host.split(":")[1]),
				   							  OneTConfiguration.DESCRIPTOR.proxyHost.split(":")[0],
											  Integer.parseInt(OneTConfiguration.DESCRIPTOR.proxyHost.split(":")[1]),
				   							  OneTConfiguration.DESCRIPTOR.credentialsId, 
				   							  OneTConfiguration.DESCRIPTOR.url, 
				   							  objectMapper.readValue(FileUtils.readFileToString(file, "UTF-8"),
 									  				 				 OneTRequest.class));
								}
								else {
									
									responseValue = apiProcessor.postJson(host.split(":")[0], 
				   							  Integer.parseInt(host.split(":")[1]), 
											  "NoProxy", 
											   0,
				   							  OneTConfiguration.DESCRIPTOR.credentialsId, 
				   							  OneTConfiguration.DESCRIPTOR.url, 
				   							  objectMapper.readValue(FileUtils.readFileToString(file, "UTF-8"), 
 									  				 				 OneTRequest.class));
								}
								
								if(responseValue.getResponseCode() == 200) {
									stringBuilder.appendLine(OneTConstants.ONET_LOG + String.format(OneTConstants.BACKUP_POST_MESSAGE, 
																									"Successful", 
																									host, 
																									responseValue.getResponseCode(), 
																									"Backup file: " + file.getName()));
									successfulPost = true;
									uploadCounterSuccess++;
									
									if(file.delete()) {
										
										stringBuilder.appendLine(OneTConstants.MESSAGE_WAS_SUCCESSFULLY_DELETED);
									}
									
									break;
								}	
								else {
									stringBuilder.appendLine(OneTConstants.ONET_LOG + String.format(OneTConstants.BACKUP_POST_MESSAGE, 
																									"Unsuccessful", 
																									host, 
																									responseValue.getResponseCode(), 
																									"N/A"));							
								}
							}
							
							if(successfulPost == false) 
								uploadCounterFailure++;
						}							
					} 
					catch (Exception e)	{
						
						success = false;
						
						stringBuilder.appendLine(OneTConstants.MESSAGE_WAS_NOT_UPLOADED);
								
						LOGGER.log(Level.SEVERE, file.getName() + OneTConstants.MESSAGE_RESPONSE_MESSAGE + responseValue.getContent());
						
						responseContent.append(OneTConstants.MESSAGE_HTML_PAGE_DOUBLE_BREAK + OneTConstants.MESSAGE_FILE_PATH + CommonUtil.getFilePath(file));
						responseContent.append(OneTConstants.MESSAGE_HTML_PAGE_SINGLE_BREAK + OneTConstants.MESSAGE_FILE_SIZE + CommonUtil.getFileSize(file));
						responseContent.append(OneTConstants.MESSAGE_HTML_PAGE_SINGLE_BREAK + OneTConstants.MESSAGE_FILE_DATE + CommonUtil.getFileDate(file));
						responseContent.append(OneTConstants.MESSAGE_HTML_PAGE_SINGLE_BREAK + OneTConstants.MESSAGE_RESPONSE_MESSAGE + responseValue.getContent());						
						
						uploadCounterFailure++;
					}
				}
				else {	
					
					stringBuilder.appendLine(OneTConstants.MESSAGE_MAXIMUM_UPLOADED_JOBS + OneTConfiguration.DESCRIPTOR.maxBackupJobs + 
										 	 OneTConstants.MESSAGE_HAS_BEEN_REACHED);
					break;
				}
				
				uploadCounterAttempted++;
			}
		}
		else {	
			
			stringBuilder.appendLine(OneTConstants.MESSAGE_DOES_NOT_EXIST);
		}
		
		stringBuilder.appendLine(String.format(OneTConstants.MESSAGE_BACKUP_STATUS, uploadCounterAttempted, uploadCounterSuccess,uploadCounterFailure));
				
		if(!success) {	
			
			if(!StringUtils.isEmpty(OneTConfiguration.DESCRIPTOR.mailSMTPHost) &&
			   !StringUtils.isEmpty(OneTConfiguration.DESCRIPTOR.mailTo) &&
			   !StringUtils.isEmpty(OneTConfiguration.DESCRIPTOR.mailFrom) &&
			   !StringUtils.isEmpty(OneTConfiguration.DESCRIPTOR.mailMessage)){
				
					EmailHelper.sendMail(OneTConfiguration.DESCRIPTOR.mailSMTPHost, 
										 OneTConfiguration.DESCRIPTOR.mailTo, 
										 OneTConfiguration.DESCRIPTOR.mailFrom, 
										 OneTConstants.MESSAGE_UPLOAD_UNSUCCESSFUL_SUBJECT + Jenkins.getInstanceOrNull().getRootUrl(),
										 OneTConfiguration.DESCRIPTOR.mailMessage + responseContent.toString());				
			}
			else
				LOGGER.log(Level.WARNING, OneTConstants.MESSAGE_MISSING_REQUIRED_FIELDS);			
		}
		
		LOGGER.log(Level.INFO, stringBuilder.toString());
		
		CommonUtil.nullifyQuietly(responseValue,
				  				  backupDirectory,
				  				  stringBuilder,
				  				  responseContent,
				  				  objectMapper);
		
		return success;
	}
	
	
	/**
	 * Backup build.
	 *
	 * @param oneTRequest the one T request
	 * @return the string
	 */
	public static String backupBuild(OneTRequest oneTRequest)
	{	
		File file = null;
		File backupDirectory = null;
		FileWriter fileWriter = null;
		BufferedWriter bufferedWriter = null;
		ObjectMapper objectMapper = null;
		
		try {			
			
			backupDirectory = new File(Jenkins.getInstanceOrNull().getRootDir() + OneTConstants.BACKUP_BUILD_DIRECTORY);
			
			if(!backupDirectory.exists())
				backupDirectory.mkdirs();						
			
			file = new File(backupDirectory, Long.toString(System.currentTimeMillis()));
			
			if (file.exists())	
				file.delete(); 
					
			file.createNewFile();			
			
			objectMapper = new ObjectMapper(); 
			fileWriter = new FileWriter(file.getAbsoluteFile());			
			bufferedWriter = new BufferedWriter(fileWriter);
			
			bufferedWriter.write(objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(oneTRequest));
			
			bufferedWriter.flush();
		} 
		catch (IOException e) {
			
			LOGGER.log(Level.SEVERE, e.toString());
		}
		finally	{	
			
			CommonUtil.nullifyQuietly(file,
									  backupDirectory,
									  fileWriter,
									  bufferedWriter,
									  objectMapper);
			
		}
		
		return OneTConstants.MESSAGE_BACKUP_PROCESSOR_FILE_CREATED + file.getAbsolutePath();
	}

}