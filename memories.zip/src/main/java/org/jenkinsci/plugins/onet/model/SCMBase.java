package org.jenkinsci.plugins.onet.model;

// TODO: Auto-generated Javadoc
/**
 * The Class SCM.
 */
public class SCMBase {
	
	/** The name. */
	private String name;
	
	/** The revision. */
	private String revision;
	
	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the revision.
	 *
	 * @return the revision
	 */
	public String getRevision() {
		return revision;
	}

	/**
	 * Sets the revision.
	 *
	 * @param revision the new revision
	 */
	public void setRevision(String revision) {
		this.revision = revision;
	}	
}
