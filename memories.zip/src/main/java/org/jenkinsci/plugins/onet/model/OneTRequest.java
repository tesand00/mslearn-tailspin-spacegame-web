package org.jenkinsci.plugins.onet.model;

import java.io.Serializable;

// TODO: Auto-generated Javadoc
/**
 * The Class OneTRequest.
 */
public class OneTRequest implements Serializable {
	
	/** The log type. */
	private String logType;
	
	/** The log level. */
	private String logLevel;
	
	/** The log timestamp. */
	private String logTimestamp;
	
	/** The body. */
	private Body body;
	
	/** The transaction. */
	private Transaction transaction;
	
	/** The runtime. */
	private Runtime runtime;
	
	/** The application. */
	private Application application;

	/**
	 * Gets the log type.
	 *
	 * @return the log type
	 */
	public String getLogType() {
		return logType;
	}

	/**
	 * Sets the log type.
	 *
	 * @param logType the new log type
	 */
	public void setLogType(String logType) {
		this.logType = logType;
	}

	/**
	 * Gets the log level.
	 *
	 * @return the log level
	 */
	public String getLogLevel() {
		return logLevel;
	}

	/**
	 * Sets the log level.
	 *
	 * @param logLevel the new log level
	 */
	public void setLogLevel(String logLevel) {
		this.logLevel = logLevel;
	}

	/**
	 * Gets the log timestamp.
	 *
	 * @return the log timestamp
	 */
	public String getLogTimestamp() {
		return logTimestamp;
	}

	/**
	 * Sets the log timestamp.
	 *
	 * @param logTimestamp the new log timestamp
	 */
	public void setLogTimestamp(String logTimestamp) {
		this.logTimestamp = logTimestamp;
	}	

	/**
	 * Gets the body.
	 *
	 * @return the body
	 */
	public Body getBody() {
		return body;
	}

	/**
	 * Sets the body.
	 *
	 * @param body the new body
	 */
	public void setBody(Body body) {
		this.body = body;
	}

	/**
	 * Gets the transaction.
	 *
	 * @return the transaction
	 */
	public Transaction getTransaction() {
		return transaction;
	}

	/**
	 * Sets the transaction.
	 *
	 * @param transaction the new transaction
	 */
	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}

	/**
	 * Gets the runtime.
	 *
	 * @return the runtime
	 */
	public Runtime getRuntime() {
		return runtime;
	}

	/**
	 * Sets the runtime.
	 *
	 * @param runtime the new runtime
	 */
	public void setRuntime(Runtime runtime) {
		this.runtime = runtime;
	}

	/**
	 * Gets the application.
	 *
	 * @return the application
	 */
	public Application getApplication() {
		return application;
	}

	/**
	 * Sets the application.
	 *
	 * @param application the new application
	 */
	public void setApplication(Application application) {
		this.application = application;
	}

}
