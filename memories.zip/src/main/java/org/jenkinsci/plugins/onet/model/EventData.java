package org.jenkinsci.plugins.onet.model;

import java.io.Serializable;

// TODO: Auto-generated Javadoc
/**
 * The Class EventData.
 */
public class EventData implements Serializable {
	
	/** The message name. */
	private String messageName;
	
	/** The message type. */
	private String messageType;
	
	/** The meta. */
	private Object meta;

	/**
	 * Gets the message name.
	 *
	 * @return the message name
	 */
	public String getMessageName() {
		return messageName;
	}

	/**
	 * Sets the message name.
	 *
	 * @param messageName the new message name
	 */
	public void setMessageName(String messageName) {
		this.messageName = messageName;
	}

	/**
	 * Gets the message type.
	 *
	 * @return the message type
	 */
	public String getMessageType() {
		return messageType;
	}

	/**
	 * Sets the message type.
	 *
	 * @param messageType the new message type
	 */
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	/**
	 * Gets the meta.
	 *
	 * @return the meta
	 */
	public Object getMeta() {
		return meta;
	}

	/**
	 * Sets the meta.
	 *
	 * @param meta the new meta
	 */
	public void setMeta(Object meta) {
		this.meta = meta;
	}
}
