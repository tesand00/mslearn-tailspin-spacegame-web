package org.jenkinsci.plugins.onet.model;

import java.io.Serializable;

// TODO: Auto-generated Javadoc
/**
 * The Class Application.
 */
public class Application implements Serializable {
	
	/** The deployment unit name. */
	private String deploymentUnitName;
	
	/** The MOTS application acronym. */
	private String MOTSApplicationAcronym;	

	/**
	 * Gets the deployment unit name.
	 *
	 * @return the deployment unit name
	 */
	public String getDeploymentUnitName() {
		return deploymentUnitName;
	}

	/**
	 * Sets the deployment unit name.
	 *
	 * @param deploymentUnitName the new deployment unit name
	 */
	public void setDeploymentUnitName(String deploymentUnitName) {
		this.deploymentUnitName = deploymentUnitName;
	}

	/**
	 * Gets the MOTS application acronym.
	 *
	 * @return the MOTS application acronym
	 */
	public String getMOTSApplicationAcronym() {
		return MOTSApplicationAcronym;
	}

	/**
	 * Sets the MOTS application acronym.
	 *
	 * @param mOTSApplicationAcronym the new MOTS application acronym
	 */
	public void setMOTSApplicationAcronym(String mOTSApplicationAcronym) {
		MOTSApplicationAcronym = mOTSApplicationAcronym;
	}

}
