package org.jenkinsci.plugins.onet.cron;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.jenkinsci.plugins.onet.constants.OneTConstants;
import org.jenkinsci.plugins.onet.processor.BackupProcessor;
import org.jenkinsci.plugins.onet.util.CommonUtil;
import org.quartz.InterruptableJob;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.UnableToInterruptJobException;

// TODO: Auto-generated Javadoc
/**
 * The Class CronJob.
 */
public class CronJob implements InterruptableJob
{
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = Logger.getLogger(CronJob.class.getName());
	
	/* (non-Javadoc)
	 * @see org.quartz.Job#execute(org.quartz.JobExecutionContext)
	 */
	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {	
		
		if(BackupProcessor.uploadBuilds())
			LOGGER.log(Level.INFO, OneTConstants.MESSAGE_BACKUP_SUCCESSFUL);
		else
			LOGGER.log(Level.SEVERE, OneTConstants.MESSAGE_BACKUP_UNSUCCESSFUL);
	}

	/* (non-Javadoc)
	 * @see org.quartz.InterruptableJob#interrupt()
	 */
	@Override
	public void interrupt() throws UnableToInterruptJobException {
		
		// To do		
	}
}
