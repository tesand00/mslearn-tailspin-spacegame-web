package org.jenkinsci.plugins.onet.cron;

import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.jenkinsci.plugins.onet.configuration.OneTConfiguration;
import org.quartz.CronTrigger;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.impl.StdSchedulerFactory;

// TODO: Auto-generated Javadoc
/**
 * The Class CronTab.
 */
public class CronTab 
{
	
	/** The idx. */
	private static long idx = 0;	
	
	/** The trigger. */
	private static CronTrigger trigger = null;
	
	/** The job. */
	private static JobDetail job = null;
	
	/** The scheduler. */
	private static Scheduler scheduler = null;
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = Logger.getLogger(CronTab.class.getName());
	
	/**
	 * Run cron job.
	 *
	 * @param cron the cron
	 */
	public static void runCronJob(String cron) {	
		
		try 
		{			
			idx++;
			
			if(scheduler == null)
				scheduler = new StdSchedulerFactory().getScheduler();
			else {		
				
				for(String groupName : scheduler.getJobGroupNames()) {
					
					for(String jobName : scheduler.getJobNames(groupName)) {
						
						if(scheduler.getJobDetail(jobName, groupName) != null) {	
							
							LOGGER.log(Level.FINEST, "Scheduled job to be deleted: " + scheduler.getJobDetail(jobName, groupName));
						
							scheduler.deleteJob(jobName, groupName);
						
							if(scheduler.getJobDetail(jobName, groupName) == null)
								LOGGER.log(Level.FINEST, "Scheduled job deleted: " + jobName);
						}
					}
				}					
			}
			
			if(OneTConfiguration.DESCRIPTOR.enabled) {
				
				if(job == null)
					job = new JobDetail();			
				
				job.setName("onetjob" + Long.toString(idx));  
		    	job.setGroup("onetgroup");
		    	job.setJobClass(CronJob.class);
			    
				if(trigger == null)			
					trigger = new CronTrigger();			
					
				trigger.setName("onettrigger" + Long.toString(idx));
				trigger.setJobName("onetjob" + Long.toString(idx));
				trigger.setJobGroup("onetgroup"); 
				trigger.setCronExpression(cron.trim());		
				
		    	scheduler.scheduleJob(job, trigger);  
		    	
		    	LOGGER.log(Level.FINEST, "Scheduled job created: " + scheduler.getJobDetail("onetjob" + Long.toString(idx), "onetgroup"));
		    	LOGGER.log(Level.FINEST, "Cron schedule: " + cron);
		    	
		    	scheduler.start();
			}				
		}
		catch (ParseException e) {
			
			LOGGER.log(Level.SEVERE, e.toString());
		} 
		catch (SchedulerException e) {
			
			LOGGER.log(Level.SEVERE, e.toString());
		}
	}
}
