package org.jenkinsci.plugins.onet.model;

import java.io.Serializable;

// TODO: Auto-generated Javadoc
/**
 * The Class Transaction.
 */
public class Transaction implements Serializable {
	
	/** The transaction id. */
	private String transactionId;
	
	/** The conversation id. */
	private String conversationId;
	
	/** The consumer. */
	private String consumer;
	
	/** The protocol. */
	private String protocol;
	
	/** The calling entity IP. */
	private String callingEntityIP;
	
	/** The received timestamp. */
	private String receivedTimestamp;
	
	/** The time to live. */
	private long timeToLive;
	
	/** The timeout timestamp. */
	private String timeoutTimestamp;

	/**
	 * Gets the transaction id.
	 *
	 * @return the transaction id
	 */
	public String getTransactionId() {
		return transactionId;
	}

	/**
	 * Sets the transaction id.
	 *
	 * @param transactionId the new transaction id
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}	

	/**
	 * Gets the conversation id.
	 *
	 * @return the conversation id
	 */
	public String getConversationId() {
		return conversationId;
	}

	/**
	 * Sets the conversation id.
	 *
	 * @param conversationId the new conversation id
	 */
	public void setConversationId(String conversationId) {
		this.conversationId = conversationId;
	}

	/**
	 * Gets the consumer.
	 *
	 * @return the consumer
	 */
	public String getConsumer() {
		return consumer;
	}

	/**
	 * Sets the consumer.
	 *
	 * @param consumer the new consumer
	 */
	public void setConsumer(String consumer) {
		this.consumer = consumer;
	}

	/**
	 * Gets the protocol.
	 *
	 * @return the protocol
	 */
	public String getProtocol() {
		return protocol;
	}

	/**
	 * Sets the protocol.
	 *
	 * @param protocol the new protocol
	 */
	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

	/**
	 * Gets the calling entity IP.
	 *
	 * @return the calling entity IP
	 */
	public String getCallingEntityIP() {
		return callingEntityIP;
	}

	/**
	 * Sets the calling entity IP.
	 *
	 * @param callingEntityIP the new calling entity IP
	 */
	public void setCallingEntityIP(String callingEntityIP) {
		this.callingEntityIP = callingEntityIP;
	}

	/**
	 * Gets the received timestamp.
	 *
	 * @return the received timestamp
	 */
	public String getReceivedTimestamp() {
		return receivedTimestamp;
	}

	/**
	 * Sets the received timestamp.
	 *
	 * @param receivedTimestamp the new received timestamp
	 */
	public void setReceivedTimestamp(String receivedTimestamp) {
		this.receivedTimestamp = receivedTimestamp;
	}

	/**
	 * Gets the time to live.
	 *
	 * @return the time to live
	 */
	public long getTimeToLive() {
		return timeToLive;
	}

	/**
	 * Sets the time to live.
	 *
	 * @param timeToLive the new time to live
	 */
	public void setTimeToLive(long timeToLive) {
		this.timeToLive = timeToLive;
	}

	/**
	 * Gets the timeout timestamp.
	 *
	 * @return the timeout timestamp
	 */
	public String getTimeoutTimestamp() {
		return timeoutTimestamp;
	}

	/**
	 * Sets the timeout timestamp.
	 *
	 * @param timeoutTimestamp the new timeout timestamp
	 */
	public void setTimeoutTimestamp(String timeoutTimestamp) {
		this.timeoutTimestamp = timeoutTimestamp;
	}
}
