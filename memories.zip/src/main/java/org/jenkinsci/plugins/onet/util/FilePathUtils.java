package org.jenkinsci.plugins.onet.util;

import java.util.Collection;
import java.util.List;

import org.apache.commons.io.filefilter.DirectoryFileFilter;
import org.apache.commons.io.filefilter.FalseFileFilter;
import org.apache.commons.io.filefilter.FileFilterUtils;
import org.apache.commons.io.filefilter.IOFileFilter;
import org.apache.commons.io.filefilter.SuffixFileFilter;
import org.apache.commons.io.filefilter.TrueFileFilter;

import hudson.FilePath;

// TODO: Auto-generated Javadoc
/**
 * The Class FilePathUtils.
 */
public class FilePathUtils {
	
	/**
	 * List files.
	 *
	 * @param directory the directory
	 * @param extensions the extensions
	 * @param recursive the recursive
	 * @return the collection
	 */
	public static Collection<FilePath> listFiles(final FilePath directory, final String[] extensions, final boolean recursive) {
		
        IOFileFilter filter;
        
        if (extensions == null) {
            filter = TrueFileFilter.INSTANCE;
        } 
        else {
            final String[] suffixes = toSuffixes(extensions);
            filter = new SuffixFileFilter(suffixes);
        }
        
        return listFiles(directory, filter,
                recursive ? TrueFileFilter.INSTANCE : FalseFileFilter.INSTANCE);
    }
	
	/**
	 * List files.
	 *
	 * @param directory the directory
	 * @param fileFilter the file filter
	 * @param dirFilter the dir filter
	 * @return the collection
	 */
	public static Collection<FilePath> listFiles(final FilePath directory, 
											     final IOFileFilter fileFilter, 
											     final IOFileFilter dirFilter) {
		
		validateListFilesParameters(directory, fileFilter);

        final IOFileFilter effFileFilter = setUpEffectiveFileFilter(fileFilter);
        final IOFileFilter effDirFilter = setUpEffectiveDirFilter(dirFilter);

        //Find files
        final Collection<FilePath> files = new java.util.LinkedList<FilePath>();
        innerListFiles(files, directory, FileFilterUtils.or(effFileFilter, effDirFilter), false);
        return files;
    }
	
	/**
	 * List files and dirs.
	 *
	 * @param directory the directory
	 * @param fileFilter the file filter
	 * @param dirFilter the dir filter
	 * @return the collection
	 */
	public static Collection<FilePath> listFilesAndDirs(final FilePath directory, 
														final IOFileFilter fileFilter, 
														final IOFileFilter dirFilter) {
		
    	validateListFilesParameters(directory, fileFilter);

    	final IOFileFilter effFileFilter = setUpEffectiveFileFilter(fileFilter);
    	final IOFileFilter effDirFilter = setUpEffectiveDirFilter(dirFilter);

    	//Find files
    	final Collection<FilePath> files = new java.util.LinkedList<FilePath>();
    	
    	try {
    		
    		if (directory.isDirectory()) {
        		files.add(directory);
        	}
    	}
    	catch(Exception e) {
    		
    	}
    	
    	innerListFiles(files, directory,
            FileFilterUtils.or(effFileFilter, effDirFilter), true);
    	
    	return files;
    }
	
	/**
	 * Sets the up effective file filter.
	 *
	 * @param fileFilter the file filter
	 * @return the IO file filter
	 */
	private static IOFileFilter setUpEffectiveFileFilter(final IOFileFilter fileFilter) {
		
        return FileFilterUtils.and(fileFilter, FileFilterUtils.notFileFilter(DirectoryFileFilter.INSTANCE));
    }
	
	/**
	 * Sets the up effective dir filter.
	 *
	 * @param dirFilter the dir filter
	 * @return the IO file filter
	 */
	private static IOFileFilter setUpEffectiveDirFilter(final IOFileFilter dirFilter) {
		
		return dirFilter == null ? FalseFileFilter.INSTANCE : FileFilterUtils.and(dirFilter, DirectoryFileFilter.INSTANCE);
	}
	
	/**
	 * Inner list files.
	 *
	 * @param files the files
	 * @param directory the directory
	 * @param filter the filter
	 * @param includeSubDirectories the include sub directories
	 */
	private static void innerListFiles(final Collection<FilePath> files, 
									   final FilePath directory, 
									   final IOFileFilter filter, 
									   final boolean includeSubDirectories) {
       
       List<FilePath> found = null;
       
       try {
    	   
    	   found = directory.list(filter);
    	   
    	   if (found != null) {
        	   
               for (final FilePath file : found) {
               	
                  if (file.isDirectory()) {
               	   
                      if (includeSubDirectories) {
                           files.add(file);
                       }
                      
                       innerListFiles(files, file, filter, includeSubDirectories);
                  } 
                  else {
                      files.add(file);
                  }
               }
           }
       }
       catch(Exception e) {
    	   
       }
       finally {
    	   
    	   found = null;
       }
    }
	
	/**
	 * Validate list files parameters.
	 *
	 * @param directory the directory
	 * @param fileFilter the file filter
	 */
	private static void validateListFilesParameters(final FilePath directory, final IOFileFilter fileFilter) {
		
		try {
			
			if (!directory.isDirectory()) {
	            throw new IllegalArgumentException("Parameter 'directory' is not a directory: " + directory);
	        }
			
		}
		catch(Exception e) {
			
		}		
		
        if (fileFilter == null) {
            throw new NullPointerException("Parameter 'fileFilter' is null");
       }
    }
	
	/**
	 * To suffixes.
	 *
	 * @param extensions the extensions
	 * @return the string[]
	 */
	private static String[] toSuffixes(final String[] extensions) {
		
        final String[] suffixes = new String[extensions.length];
        
        for (int i = 0; i < extensions.length; i++) {
            suffixes[i] = "." + extensions[i];
        }
        
        return suffixes;
    }

}
