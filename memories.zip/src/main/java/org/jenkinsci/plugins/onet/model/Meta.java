package org.jenkinsci.plugins.onet.model;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.jenkinsci.plugins.onet.model.FlowNodeData;
import org.jenkinsci.plugins.onet.util.CommonUtil;

// TODO: Auto-generated Javadoc
/**
 * The Class BuildData.
 */
public class Meta
{	
	/** The build duration. */
	private long buildDuration;	
	
	/** The build number. */
	private int buildNumber;	
	
	/** The build result. */
	private String buildResult;	
	
	/** The build type. */
	private String buildType;
	
	/** The build started by. */
	private String buildStartedBy;
	
	/** The build user. */
	private String buildUser;	
	
	/** The build variables. */
	private Map<String,String> buildVariables;	
	
	/** The folder variables. */
	private Map<String,String> folderVariables;	
	
	/** The report variables. */
	private Map<String,String> reportVariables;	
	
	/** The job name. */
	private String jobName;
	
	/** The build log. */
	private List<String> buildLog;
	
	/** The jenkins agents. */
	private List<String> agents; 	 
	
	/** The scms. */
	private Map<String, List> scms;
	
	/** The pipeline data. */
	private FlowNodeData pipelineData;
	
	/** The instance url. */
	private String instanceUrl;		
	
	/** The instance version. */
	private String instanceVersion;	
	
	/** The plugin version. */
	private String pluginVersion;
	
	/** The config file. */
	private String configFile;
	
	/** The description. */
	private String description;
	
	/** The artifacts. */
	private Set<Artifact> artifacts;
	
	/**
	 * Gets the builds the duration.
	 *
	 * @return the builds the duration
	 */
	public long getBuildDuration()
	{
		return buildDuration;
	}
	
	/**
	 * Sets the builds the duration.
	 *
	 * @param buildDuration the new builds the duration
	 */
	public void setBuildDuration(long buildDuration) {
		
		this.buildDuration = buildDuration;
	}
	
	/**
	 * Gets the builds the number.
	 *
	 * @return the builds the number
	 */
	public int getBuildNumber()	{
		
		return buildNumber;
	}
	
	/**
	 * Sets the builds the number.
	 *
	 * @param buildNumber the new builds the number
	 */
	public void setBuildNumber(int buildNumber)	{
		
		this.buildNumber = buildNumber;
	}
	
	/**
	 * Gets the builds the result.
	 *
	 * @return the builds the result
	 */
	public String getBuildResult() {
		
		return buildResult;
	}
	
	/**
	 * Sets the builds the result.
	 *
	 * @param buildResult the new builds the result
	 */
	public void setBuildResult(String buildResult) {
		
		this.buildResult = buildResult;
	}
	
	/**
	 * Gets the builds the type.
	 *
	 * @return the builds the type
	 */
	public String getBuildType() {
		
		return buildType;
	}

	/**
	 * Sets the builds the type.
	 *
	 * @param buildType the new builds the type
	 */
	public void setBuildType(String buildType) {
		
		this.buildType = buildType;
	}

	/**
	 * Gets the builds the started by.
	 *
	 * @return the builds the started by
	 */
	public String getBuildStartedBy() {
		
		return buildStartedBy;
	}

	/**
	 * Sets the builds the started by.
	 *
	 * @param buildStartedBy the new builds the started by
	 */
	public void setBuildStartedBy(String buildStartedBy) {
		
		this.buildStartedBy = buildStartedBy;
	}
	
	/**
	 * Gets the builds the user.
	 *
	 * @return the builds the user
	 */
	public String getBuildUser() {
		
		return buildUser;
	}	

	/**
	 * Sets the builds the user.
	 *
	 * @param buildUser the new builds the user
	 */
	public void setBuildUser(String buildUser) {
		
		this.buildUser = buildUser;
	}
	
	/**
	 * Gets the builds the variables.
	 *
	 * @return the builds the variables
	 */
	public Map<String, String> getBuildVariables() {
		
		return buildVariables;
	}
	
	/**
	 * Sets the build variables.
	 *
	 * @param buildVariables the build variables
	 */
	public void setBuildVariables(Map<String, String> buildVariables) {
		
		this.buildVariables = buildVariables;
	}	

	/**
	 * Gets the folder variables.
	 *
	 * @return the folder variables
	 */
	public Map<String, String> getFolderVariables() {
		return folderVariables;
	}

	/**
	 * Sets the folder variables.
	 *
	 * @param folderVariables the folder variables
	 */
	public void setFolderVariables(Map<String, String> folderVariables) {
		this.folderVariables = folderVariables;
	}

	/**
	 * Gets the job name.
	 *
	 * @return the job name
	 */
	public String getJobName() {
		
		return jobName;
	}
	
	/**
	 * Sets the job name.
	 *
	 * @param jobName the new job name
	 */
	public void setJobName(String jobName) {
		
		this.jobName = jobName;
	}
	
	/**
	 * Gets the builds the log.
	 *
	 * @return the builds the log
	 */
	public List<String> getBuildLog() {
		
		return buildLog;
	}

	/**
	 * Gets the pipeline data.
	 *
	 * @return the pipeline data
	 */
	public FlowNodeData getPipelineData() {
		
		return pipelineData;
	}
	
	
	/**
	 * Sets the pipeline data.
	 *
	 * @param data the new pipeline data
	 */
	public void setPipelineData(FlowNodeData data) {
		
		this.pipelineData= data;
	}
	
	/**
	 * Sets the builds the log.
	 *
	 * @param buildLog the new builds the log
	 */
	public void setBuildLog(List<String> buildLog) {
		
        this.buildLog = CommonUtil.escapeMetaCharacters(buildLog);
	}
	

	/**
	 * Gets the instance url.
	 *
	 * @return the instance url
	 */
	public String getInstanceUrl() {
		
		return instanceUrl;
	}
	
	/**
	 * Sets the instance url.
	 *
	 * @param instanceUrl the new instance url
	 */
	public void setInstanceUrl(String instanceUrl) {
		
		this.instanceUrl = instanceUrl;
	}
	
	/**
	 * Gets the instance version.
	 *
	 * @return the instance version
	 */
	public String getInstanceVersion() {
		
		return instanceVersion;
	}
	
	/**
	 * Sets the instance version.
	 *
	 * @param instanceVersion the new instance version
	 */
	public void setInstanceVersion(String instanceVersion) { 
		
		this.instanceVersion = instanceVersion;
	}	
	
	/**
	 * Gets the plugin version.
	 *
	 * @return the plugin version
	 */
	public String getPluginVersion() {
		return pluginVersion;
	}

	/**
	 * Sets the plugin version.
	 *
	 * @param pluginVersion the new plugin version
	 */
	public void setPluginVersion(String pluginVersion) {
		this.pluginVersion = pluginVersion;
	}	

	/**
	 * Gets the config file.
	 *
	 * @return the config file
	 */
	public String getConfigFile() {
		return configFile;
	}

	/**
	 * Sets the config file.
	 *
	 * @param configFile the new config file
	 */
	public void setConfigFile(String configFile) {
		this.configFile = configFile;
	}

	/**
	 * Gets the report variables.
	 *
	 * @return the report variables
	 */
	public Map<String,String> getReportVariables() {
		
		return reportVariables;
	}

	/**
	 * Sets the report variables.
	 *
	 * @param reportVariables the report variables
	 */
	public void setReportVariables(Map<String,String> reportVariables) {
		
		this.reportVariables = reportVariables;
	}
	
	/**
	 * Gets the agents.
	 *
	 * @return the agents
	 */
	public List<String> getAgents() {
		return agents;
	}

	/**
	 * Sets the agents.
	 *
	 * @param agents the new agents
	 */
	public void setAgents(List<String> agents) {
	    this.agents = agents;
	}

	/**
	 * Gets the scms.
	 *
	 * @return the scms
	 */
	public Map<String, List> getScms() {
		return scms;
	}

	/**
	 * Sets the scms.
	 *
	 * @param scms the scms
	 */
	public void setScms(Map<String, List> scms) {
		this.scms = scms;
	}	

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Sets the description.
	 *
	 * @param description the new description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Gets the artifacts.
	 *
	 * @return the artifacts
	 */
	public Set<Artifact> getArtifacts() {
		return artifacts;
	}

	/**
	 * Sets the artifacts.
	 *
	 * @param artifacts the new artifacts
	 */
	public void setArtifacts(Set<Artifact> artifacts) {
		this.artifacts = artifacts;
	}	
}