package org.jenkinsci.plugins.onet.model;

import java.util.List;
import java.io.Serializable;

import org.jenkinsci.plugins.workflow.cps.CpsFlowExecution;

import hudson.scm.SCM;

// TODO: Auto-generated Javadoc
/**
 * The Class FlowNodeData.
 */
public class FlowNodeData implements Serializable
{
	
	/** The stages. */
	private List<Stage> stages;
	
	/** The script. */
    private String script; 
       
    /** The executor. */
    private String executor;
	/**
	 * Gets the stages.
	 *
	 * @return the stages
	 */
	public List<Stage> getStages() {
		
		return stages;
	}

	/**
	 * Sets the stages.
	 *
	 * @param stages the new stages
	 */
	public void setStages(List<Stage> stages) {
		
		this.stages = stages;
	}

	/**
	 * Gets the script.
	 *
	 * @return the script
	 */
	public String getScript() {
		
		return script;
	}

	/**
	 * Sets the script.
	 *
	 * @param script the new script
	 */
	public void setScript(String script) {
		
		this.script = script;
	}

    /**
     * Gets the executor.
     *
     * @return the executor
     */
    public String getExecutor() {
        return executor;
    }

	/**
	 * Sets the executor.
	 *
	 * @param executor the new executor
	 */
	public void setExecutor(String executor) {
	   this.executor = executor;
	}  
}
