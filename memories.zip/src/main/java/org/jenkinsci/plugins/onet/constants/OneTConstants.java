package org.jenkinsci.plugins.onet.constants;

// TODO: Auto-generated Javadoc
/**
 * The Class OneTConstants.
 */
public class OneTConstants {
	
	
	/** The Constant ONET_NAME. */
	public static final String ONET_NAME = "One T Plugin";	
	
	/** The Constant ONET_TITLE. */
	public static final String ONET_TITLE = "One T";
	
	/** The Constant ONET_LOG. */
	public static final String ONET_LOG = "[One T] ";
	
	/** The Constant BACKUP_BUILD_DIRECTORY. */
	public static final String BACKUP_BUILD_DIRECTORY = "/onet/build/";
	
	/** The Constant BUILD_UUID. */
	public static final String BUILD_UUID = "BUILD_UUID";
	
	/** The Constant MESSAGE_RUN_STARTED. */
	public static final String MESSAGE_RUN_STARTED = "OneT started ";
	
	 /** The Constant JOB_CAUSE_UNKNOWN. */
    public static final String JOB_CAUSE_UNKNOWN = "unknown";
    
    /** The Constant JOB_CAUSE_ANONYMOUS. */
    public static final String JOB_CAUSE_ANONYMOUS = "anonymous";	
     
    /** The Constant BACKUP_POST_MESSAGE. */
    public static final String BACKUP_POST_MESSAGE = "Backup post to Kafka - Status: %s | Host: %s | Response Code: %s | Description: %s";
    
    /** The Constant EVENT_POST_MESSAGE. */
    public static final String EVENT_POST_MESSAGE = "Post to Kafka - Status: %s | Host: %s | Response Code: %s | Description: %s";
    
    /** The Constant MESSAGE_BUILD_CHECKING_UPLOAD. */
    public static final String MESSAGE_BUILD_CHECKING_UPLOAD = "Checking for builds to upload";
    
	/** The Constant MESSAGE_NUMBER_BACKED_UP_JOBS. */
	public static final String MESSAGE_NUMBER_BACKED_UP_JOBS = "Number of backed-up jobs: ";
	
	/** The Constant MESSAGE_WAS_SUCCESSFULLY_UPLOADED. */
	public static final String MESSAGE_WAS_SUCCESSFULLY_UPLOADED = " was sucessfully uploaded";
	
	/** The Constant MESSAGE_WAS_SUCCESSFULLY_DELETED. */
	public static final String MESSAGE_WAS_SUCCESSFULLY_DELETED = " was successfully deleted";
	
	/** The Constant MESSAGE_WAS_NOT_UPLOADED. */
	public static final String MESSAGE_WAS_NOT_UPLOADED = " was not uploaded ";

	public static final String MESSAGE_HTML_PAGE_SINGLE_BREAK = "<br>";
	
	public static final String MESSAGE_HTML_PAGE_DOUBLE_BREAK = "<br><br>";
	
	/** The Constant MESSAGE_FILE_FILE. */
	public static final String MESSAGE_FILE_PATH = " File Path: ";
	
	/** The Constant MESSAGE_FILE_SIZE. */
	public static final String MESSAGE_FILE_SIZE = " File Size: ";
	
	/** The Constant MESSAGE_FILE_DATE. */
	public static final String MESSAGE_FILE_DATE = " File Date: ";
	
	/** The Constant MESSAGE_RESPONSE_MESSAGE. */
	public static final String MESSAGE_RESPONSE_MESSAGE = " Response message: ";
	
	/** The Constant MESSAGE_MAXIMUM_UPLOADED_JOBS. */
	public static final String MESSAGE_MAXIMUM_UPLOADED_JOBS = "Maximum of uploaded jobs (";
	
	/** The Constant MESSAGE_HAS_BEEN_REACHED. */
	public static final String MESSAGE_HAS_BEEN_REACHED = ") has been reached";
	
	/** The Constant MESSAGE_DOES_NOT_EXIST. */
	public static final String MESSAGE_DOES_NOT_EXIST = " does not exist";
	
	/** The Constant MESSAGE_BACKUP_STATUS. */
	public static final String MESSAGE_BACKUP_STATUS = "Backup status: Attempted: %s | Successful: %s | Failed: %s";
	
	/** The Constant MESSAGE_UPLOAD_UNSUCCESSFUL_SUBJECT. */
	public static final String MESSAGE_UPLOAD_UNSUCCESSFUL_SUBJECT = "Upload of backup files was unsuccessful: ";
	
	/** The Constant MESSAGE_MISSING_REQUIRED_FIELDS. */
	public static final String MESSAGE_MISSING_REQUIRED_FIELDS = "Missing required field(s)";
	
	/** The Constant MESSAGE_BACKUP_PROCESSOR_FILE_CREATED. */
	public static final String MESSAGE_BACKUP_PROCESSOR_FILE_CREATED = "Backup file created: ";
	
	/** The Constant MESSAGE_BACKUP_PROCESSOR_FILE_FAILED. */
	public static final String MESSAGE_BACKUP_PROCESSOR_FILE_FAILED = "Backup file moved to failed directory: ";
	
	/** The Constant WORKFLOW_JOB_CLASS. */
	public static final String WORKFLOW_JOB_CLASS = "org.jenkinsci.plugins.workflow.job.WorkflowJob";
	
	/** The Constant MESSAGE_BACKUP_SUCCESSFUL. */
	public static final String MESSAGE_BACKUP_SUCCESSFUL = "Backup Successful";
	
	/** The Constant MESSAGE_BACKUP_UNSUCCESSFUL. */
	public static final String MESSAGE_BACKUP_UNSUCCESSFUL = "Backup Unsuccessful";
	
	/**  The Constant node type. */
    public static final String STAGE_NODE_TYPE = "Stage";
    
  
    /** The Constant STAGE_NODE_TYPE_START. */
    public static final String STAGE_NODE_TYPE_START = "Stage : Start";
    
   
    /** The Constant STAGE_NODE_TYPE_END. */
    public static final String STAGE_NODE_TYPE_END = "Stage : End";
    
    /**  The Constant node type. */
    public static final String ALLOCATE_NODE_TYPE = "Allocate node";
    
    /** The Constant stage node type. */
    public static final String ALLOCATE_NODE_TYPE_END = "Allocate node : End";

}
