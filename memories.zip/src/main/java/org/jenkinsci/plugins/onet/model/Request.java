package org.jenkinsci.plugins.onet.model;

import java.io.Serializable;
/**
 * The Class Request.
 */
public class Request implements Serializable {

}