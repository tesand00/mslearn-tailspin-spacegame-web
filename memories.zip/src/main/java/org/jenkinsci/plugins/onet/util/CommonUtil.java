package org.jenkinsci.plugins.onet.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLDecoder;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import javax.annotation.CheckForNull;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.jenkinsci.plugins.onet.action.ConversationIDAction;
import org.jenkinsci.plugins.onet.action.IdentifierAction;
import org.jenkinsci.plugins.onet.configuration.FolderConfiguration;
import org.jenkinsci.plugins.onet.configuration.OneTConfiguration;
import org.jenkinsci.plugins.onet.constants.OneTConstants;
import org.jenkinsci.plugins.onet.model.Artifact;
import org.jenkinsci.plugins.onet.model.SCMBase;
import org.jenkinsci.plugins.onet.model.SCMGit;
import org.jenkinsci.plugins.onet.workspace.WorkspaceFile;
import org.jenkinsci.plugins.workflow.actions.WorkspaceAction;
import org.jenkinsci.plugins.workflow.cps.CpsFlowExecution;
import org.jenkinsci.plugins.workflow.cps.EnvActionImpl;
import org.jenkinsci.plugins.workflow.cps.nodes.StepStartNode;
import org.jenkinsci.plugins.workflow.flow.FlowExecution;
import org.jenkinsci.plugins.workflow.flow.FlowExecutionOwner;
import org.jenkinsci.plugins.workflow.graph.FlowGraphWalker;
import org.jenkinsci.plugins.workflow.graph.FlowNode;
import org.jenkinsci.plugins.workflow.job.WorkflowRun;
import org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject;
import org.jenkinsci.plugins.workflow.support.actions.WorkspaceActionImpl;
import org.jenkinsci.remoting.RoleChecker;

import com.cloudbees.hudson.plugins.folder.AbstractFolderProperty;
import com.cloudbees.hudson.plugins.folder.Folder;
import com.cloudbees.plugins.credentials.CredentialsMatchers;
import com.cloudbees.plugins.credentials.CredentialsProvider;
import com.cloudbees.plugins.credentials.impl.UsernamePasswordCredentialsImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mig82.folders.properties.FolderProperties;
import com.mig82.folders.properties.StringProperty;

import hudson.EnvVars;
import hudson.FilePath;
import hudson.FilePath.FileCallable;
import hudson.PluginWrapper;
import hudson.model.AbstractBuild;
import hudson.model.Action;
import hudson.model.Cause;
import hudson.model.Item;
import hudson.model.Job;
import hudson.model.ParameterDefinition;
import hudson.model.ParameterValue;
import hudson.model.ParametersAction;
import hudson.model.ParametersDefinitionProperty;
import hudson.model.Run;
import hudson.model.StringParameterValue;
import hudson.model.TaskListener;
import hudson.model.Cause.RemoteCause;
import hudson.model.Cause.UpstreamCause;
import hudson.model.Cause.UserIdCause;
import hudson.plugins.git.GitSCM;
import hudson.plugins.git.UserRemoteConfig;
import hudson.plugins.git.util.BuildData;
import hudson.remoting.Channel;
import hudson.remoting.VirtualChannel;
import hudson.scm.SCM;
import hudson.security.ACL;
import hudson.triggers.SCMTrigger.SCMTriggerCause;
import hudson.triggers.TimerTrigger.TimerTriggerCause;
import jenkins.model.Jenkins;

// TODO: Auto-generated Javadoc
/**
 * The Class CommonUtil.
 */
public class CommonUtil {	
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = Logger.getLogger(CommonUtil.class.getName());	
	
	/**
	 * Gets the plugin version.
	 *
	 * @return the plugin version
	 */
	public static String getPluginVersion() {
		
		return Jenkins.get().getPluginManager().getPlugin("onet-plugin").getVersion();
	}
	
	/**
	 * Do record.
	 *
	 * @param run the run
	 * @return true, if successful
	 */
	public static boolean doRecord(Run run) {
		
		if(OneTConfiguration.DESCRIPTOR.enabled && 
		   !run.getParent().getClass().getName().equals("hudson.maven.MavenModule")) {			
			return true;
		}	
		else {
			
			return false;	
		}	
	}
	
	/**
	 * Gets the system time.
	 *
	 * @return the system time
	 */
	public static String getLocalSystemTime() {
		SimpleDateFormat time_formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss-SSSS");
	    String time = time_formatter.format(System.currentTimeMillis());
	    
	    return time;
	}
	
	/**
	 * Gets the central system time.
	 *
	 * @return the central system time
	 */
	public static String getCentralSystemTime() {
		
		SimpleDateFormat time_formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		time_formatter.setTimeZone(TimeZone.getTimeZone("America/Chicago"));
		String time = time_formatter.format(System.currentTimeMillis());
	
		return time;
	}
	
	/**
	 * Gets the GMT system time.
	 *
	 * @return the GMT system time
	 */
	public static String getGMTSystemTime() {
		
		SimpleDateFormat time_formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		time_formatter.setTimeZone(TimeZone.getTimeZone("GMT"));
		String time = time_formatter.format(System.currentTimeMillis());
	
		return time;
	}
	
	/**
	 * Gets the system date.
	 *
	 * @return the system date
	 */
	public static String getSystemDate()
	{
		SimpleDateFormat time_formatter = new SimpleDateFormat("yyyy.MM.dd");
	    String time = time_formatter.format(System.currentTimeMillis());
	    
	    return time;
	}
	
	/**
	 * Gets the system date and hour.
	 *
	 * @return the system date and hour
	 */
	public static String getSystemDateAndHour()
	{ 
		SimpleDateFormat time_formatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
	    String time = time_formatter.format(System.currentTimeMillis());
	    
	    return time;
	}

	/**
	 * List to string.
	 *
	 * @param list the list
	 * @return the string
	 */
	public static String listToString(List<String> list)
	{
		StringBuilder stringBuilder = new StringBuilder();
		
		for(String line : list)
		{
			stringBuilder.append(line + "\n");
		}
		
		return stringBuilder.toString();
	}

	/**
	 * String to list.
	 *
	 * @param string the string
	 * @return the list
	 */
	public static List<String> stringToList(String string)
	{		
	    String[] stringArray = string.split("\n");
		
		return Arrays.asList(stringArray);
	}	
	
	/**
	 * Gets the started by.
	 *
	 * @param run the run
	 * @return the started by
	 */
	public static String getStartedBy(Run run)
	{		
		try {
			if(StringUtils.isNotBlank(run.getCause(Cause.class).getShortDescription()))
				return run.getCause(Cause.class).getShortDescription();
		}
		catch(Exception e) {
			LOGGER.log(Level.SEVERE, e.toString());
		}		
		
		return "unknown";
	}
	
	/**
	 * Gets the cause type.
	 *
	 * @param run the run
	 * @return the cause type
	 */
	public static String getCauseType(Run run)
	{
		try	{	
			if(StringUtils.isNotBlank(run.getCause(Cause.class).getClass().getName()))
				return run.getCause(Cause.class).getClass().getName();
		}
		catch(Exception e) {
			LOGGER.log(Level.SEVERE, e.toString());
		}		
		
		return "unknown";	
	}
	
	/**
	 * Gets the user id.
	 *
	 * @param run the run
	 * @return the user id
	 */
	public static String getUserId(Run run)
	{
		try {
			if(StringUtils.isNotBlank(((UserIdCause) run.getCause(UserIdCause.class)).getUserId()))				
				return ((UserIdCause) run.getCause(UserIdCause.class)).getUserId();					
		}
		catch(Exception e){}		
		
		return "unknown";
	}
		
	/**
	 * Read file to string.
	 *
	 * @param path the path
	 * @return the string
	 */
	public static String readFileToString(String path)
	{
		BufferedReader bufferReader = null;
		
	    try 
	    {
	    	bufferReader = new BufferedReader(new FileReader(path));
	    	
	        StringBuilder stringBuilder = new StringBuilder();
	        String line = bufferReader.readLine();

	        while (line != null) 
	        {
	        	stringBuilder.append(line + "\n");
	            line = bufferReader.readLine();
	        }
	        
	        return stringBuilder.toString();
	    } 
	    catch (FileNotFoundException e)
		{
	    	LOGGER.log(Level.SEVERE, e.toString());
		} 
	    catch (IOException e)
		{
	    	LOGGER.log(Level.SEVERE, e.toString());
		} 
	    finally 
	    {
	    	try
			{
				bufferReader.close();
			} 
	    	catch (IOException e)
			{
	    		// Do nothing
			}
	    }
	    
		return null;
	}
	
	/**
	 * Format context root.
	 *
	 * @param context the context
	 * @return the string
	 */
	public static String formatContextRoot(String context)
	{
		context = StringUtils.removeStart(context, "/");
		context = StringUtils.removeStart(context, "\\");
		
		context = StringUtils.removeEnd(context, "/");
		context = StringUtils.removeEnd(context, "\\");
		
		return "/" + context;
	}	
	
	/**
	 * Check string null.
	 *
	 * @param stringList the string list
	 * @return true, if successful
	 */
	public static boolean checkStringNull(List<String> stringList)
	{
		boolean valid = true;
		
		for(String element : stringList)
		{
			if(!StringUtils.isEmpty(element))
				return false;
		}
		
		return true;
	}
	
	/**
	 * Resolve variables.
	 *
	 * @param text the text
	 * @return the string
	 */
	public static String resolveVariables(String text, Run run) {		
	
	    for (Object key : System.getProperties().keySet()) {
	    	
	    	if(text.contains("$" + key.toString()))
	        	text = text.replace("$" + key.toString(), System.getProperties().get(key).toString());
	        if(text.contains("${" + key.toString() +"}"))
	        	text = text.replace("${" + key.toString() +"}", System.getProperties().get(key).toString());	    		    	
	    }
		
		if(text.contains("$JENKINS_URL"))
			text = text.replace("$JENKINS_URL", Jenkins.get().getRootUrl());
		if(text.contains("${JENKINS_URL}"))
			text = text.replace("${JENKINS_URL}", Jenkins.get().getRootUrl());	
		
		if(text.contains("$DATE"))
			text = text.replace("$DATE", getSystemDate());
		if(text.contains("${DATE}"))
			text = text.replace("${DATE}", getSystemDate());
		
		if(text.contains("$TIME"))
			text = text.replace("$TIME", getLocalSystemTime());
		if(text.contains("${TIME}"))
			text = text.replace("${TIME}", getLocalSystemTime());
		
		if(text.contains("$JOB_NAME") && run != null) 
			text = text.replace("$JOB_NAME", run.getParent().getFullName());
		if(text.contains("${JOB_NAME}") && run != null)
			text = text.replace("${JOB_NAME}", run.getParent().getFullName());
		
		if(text.contains("$TEAMSPACE") && run != null) 
			text = text.replace("$TEAMSPACE", getFolderName(run));
		if(text.contains("${TEAMSPACE}") && run != null)
			text = text.replace("${TEAMSPACE}", getFolderName(run));
		
		if(text.contains("$MOTSID") && run != null) 
			text = text.replace("$MOTSID", run.getAction(IdentifierAction.class).getID());
		if(text.contains("${MOTSID}") && run != null)
			text = text.replace("${MOTSID}", run.getAction(IdentifierAction.class).getID());
		
		return text;
	}
    
    /**
     * Process env vars.
     *
     * @param run the run
     * @param listener the listener
     * @return the env vars
     */
    public static EnvVars processEnvVars(Run run, TaskListener listener) {
    	
        EnvVars envVars = new EnvVars();
        String value = new String();       
        
        try {    		
        	
	    	envVars.putAll(run.getEnvironment(listener));
	    	
	    	for(Action action : run.getAllActions()) {
	    		
	    		if(action instanceof EnvActionImpl) 
	    			envVars.putAll(((EnvActionImpl) action).getEnvironment());	    		
	    		else if(action instanceof ParametersAction) {
	    			
	    			List<String> sensitiveParameters = run.getAction(ParametersAction.class).getParameters().stream()
	    	                .filter(p -> p.isSensitive())
	    	                .map(ParameterValue::getName)
	    	                .collect(Collectors.toList());

	    	        for (Map.Entry<String, String> entry :run.getEnvironment(listener).entrySet()) {
	    	        	
	    	            if (sensitiveParameters.contains(entry.getKey()))
	    	            	value = "********";	    	            
	    	            else if (entry.getKey().toLowerCase().contains("password"))
	    	                value = "********";	    	            
	    	            else
	    	                value = entry.getValue();	    	            
	    	            
	    	            envVars.put(entry.getKey(), value);
	    	        }
	    		}	    		
	    	}
	    	
	    	return envVars;
    	}
        catch(Exception e) {
        	LOGGER.log(Level.SEVERE, e.getMessage());
        }
        finally {
        	
        	nullifyQuietly(envVars, value);
        }
        
        return null;
    }
    
    /**
     * Split string.
     *
     * @param string the string
     * @param token the token
     * @return the list
     */
    public static List<String> splitString(String string, String token) {
    	
    	List<String> list = new ArrayList<String>();
    	
    	String output = new String();
    	
    	for(String element : string.split(token)) {
    		
    		if(output.isEmpty())
    			output = element;
    		else
    			output += token + element;
    		
    		list.add(output);
    	}
    	
    	return list;
    }    
    
    /**
     * Process folder vars.
     *
     * @param run the run
     * @param listener the listener
     * @return the env vars
     */
    public static EnvVars processFolderVars(Run run, TaskListener listener) { 
    	
    	EnvVars envVars = null;
    	Item item = null;
    	
    	try {
    		
    		envVars = new EnvVars();
    		
    		if(run.getParent().getFullName().contains("/")) {    		    				
    			
    			for(String element : splitString(run.getParent().getFullName(),"/")) { 
    				
    				item = Jenkins.get().getItemByFullName(element);
    				
    				if(item instanceof Folder) {
    					
    					for(Object object : ((Folder) item).getProperties()) {
    						
    						if(object instanceof FolderProperties) {							
    							
    							for(StringProperty stringProperty : ((FolderProperties)object).getProperties())	{
    								
    								envVars.put(stringProperty.getKey(), resolveVariables(stringProperty.getValue(), run));								
    							}							
    						}						
    					}
    				}				
    			}			
    		}
    		
    		return envVars;    		
    	}
    	catch(Exception e) {
        	LOGGER.log(Level.SEVERE, e.getMessage());
        }
        finally {
        	
        	nullifyQuietly(envVars, item);
        }
        
        return null;
	}
    	
	/**
	 * escape special characters that are present in the build log.
	 *
	 * @param rawLog the raw build log
	 * @return escapedLog the escaped build log
	 */    
     public static List<String> escapeMetaCharacters(List<String> rawLog)
     {
         List<String> escapedLog = new ArrayList<String>();
         
         for (String str : rawLog) {
        	 
            escapedLog.add(StringEscapeUtils.escapeHtml(str));
         }
          
         return escapedLog;
     }

     
	/**
	 * Gets the execution.
	 *
	 * @param run the run
	 * @return the execution
	 */
	public @CheckForNull static CpsFlowExecution getExecution(Run run) {
		
        FlowExecutionOwner owner = ((FlowExecutionOwner.Executable) run).asFlowExecutionOwner();
        
        if (owner == null) {
        	
            return null;
        }
        
        FlowExecution exec = owner.getOrNull();
        
        return exec instanceof CpsFlowExecution ? (CpsFlowExecution) exec : null;
    }
	
	public static String getFolderName(Run run) {

		if(run.getParent().getFullName().contains("/")) {    		    				
			
			for(String element : run.getParent().getFullName().split("/")) { 
				
				if(Jenkins.get().getItemByFullName(element) instanceof Folder 
						&& ((Folder) Jenkins.get().getItemByFullName(element)).getName().startsWith("com.att"))
					return ((Folder) Jenkins.get().getItemByFullName(element)).getName();
			}
		}
	
        return "N/A";				
	}
	
	/**
	 * Gets the folder name.
	 *
	 * @param run the run
	 * @return the folder name
	 */
	public static String getFolderName(Run run, TaskListener listener) {
		
		Job job = run.getParent();
		
		LOGGER.log(Level.FINEST, "In CommonUtil.getFolderName() Job Full Name: " + job.getFullName());
		
		String returnValue = new String();
		
		if(job.getFullName().contains("/")) {
			
			String[] elements = job.getFullName().split("/");
	    	StringBuilder elementBuilder = new StringBuilder();
	    	List<String> folders = new ArrayList<String>();
	    	
	    	for(String element : elements) { 
	    		
	    		elementBuilder.append(element + "/");	    		
	    		folders.add(StringUtils.removeEnd(elementBuilder.toString(), "/"));    		    		
	    	} 
	    	
	    	for(String folder : folders) {	    			    		
	    		
	    		if(Jenkins.get().getItemByFullName(folder) instanceof Folder && folder.contains("com.att")) {
	    			
	    			if(folder.contains("/"))
	    				returnValue = StringUtils.substringAfterLast(folder,"/");
	    			else
	    				returnValue = folder;
	    		}	    		
	    	}		
		}
		
		return returnValue;
	}	
		
	/**
	 * Process report data.
	 *
	 * @param run the run
	 * @return the env vars
	 */
	public static EnvVars processReportData(Run run) { 
		
		Job job = run.getParent();

		LOGGER.log(Level.FINEST, "In CommonUtil.processReportData() Job Full Name: " + job.getFullName());
				
		List<WorkspaceFile> workspaceFiles = new ArrayList<WorkspaceFile>();		
		EnvVars returnVars = new EnvVars();
		String result = null;
		
	
		if(job.getFullName().contains("/")) {			
			
			String[] elements = job.getFullName().split("/");
	    	StringBuilder elementBuilder = new StringBuilder();
	    	List<String> folders = new ArrayList<String>();
	    	
	    	for(String element : elements) { 
	    		
	    		elementBuilder.append(element + "/");	    		
	    		folders.add(StringUtils.removeEnd(elementBuilder.toString(), "/"));    		    		
	    	} 
	    	
	    	Collections.reverse(folders);
	    	
	    	for(String folder : folders) {
	    		
	    		Item item = Jenkins.get().getItemByFullName(folder);
	    		
	    		if(item instanceof Folder) {	
					
	    			LOGGER.log(Level.FINEST,"In CommonUtil.processReportData() Folder Object: " + ((Folder) item).getFullName());
						
					for(AbstractFolderProperty<?> folderProperty : ((Folder) item).getProperties()) {
					
						if(folderProperty instanceof FolderConfiguration) {
							
							try {
								workspaceFiles.addAll(((FolderConfiguration) folderProperty).getWorkspaceFiles());
							}
							catch(Exception e) {
								LOGGER.log(Level.FINEST, "In CommonUtil.processReportData() Folder: " + folder + " | Exception: " + e.getMessage());
							}
						}
					}		
				}
				else if(item instanceof WorkflowMultiBranchProject) {
					
					LOGGER.log(Level.FINEST, "In CommonUtil.processReportData() Workflow Object: " + ((WorkflowMultiBranchProject) item).getFullName());
					
					for(AbstractFolderProperty<?> folderProperty : ((WorkflowMultiBranchProject) item).getProperties()) {
						
						if(folderProperty instanceof FolderConfiguration) {
							
							try {
								workspaceFiles.addAll(((FolderConfiguration) folderProperty).getWorkspaceFiles());
							}
							catch(Exception e) {
								LOGGER.log(Level.FINEST, "In CommonUtil.processReportData() Folder: " + folder + " | Exception: " + e.getMessage());
							}
						}				
					}
				}
	    	}
		}
		
 		if(OneTConfiguration.DESCRIPTOR.workspaceFiles != null)
 			workspaceFiles.addAll(OneTConfiguration.DESCRIPTOR.workspaceFiles); 
 		
 		workspaceFiles = removeEmptyElements(workspaceFiles);
 		
 		if(!workspaceFiles.isEmpty()) { 			
 		 	
 		 	if (!job.getClass().getName().equals("org.jenkinsci.plugins.workflow.job.WorkflowJob")) {
 		 		
 		 		for(WorkspaceFile workspaceFile : workspaceFiles) {
 		 					 			
 		 			if (workspaceFile == null || workspaceFile.filePath==null || workspaceFile.filePath.isEmpty()) 
 		 			    return null;
 		 			
 		 			
 		 			FilePath ws = run.getExecutor().getCurrentWorkspace();
 	  				
 	  		    	if(ws.isRemote()) {	  
 	  		    		
 	  					Channel channel = (Channel) ws.getChannel();
 	  					FilePath fp = new FilePath(channel,ws + workspaceFile.filePath);	
 	  				
 	  							
 	  					try {
 	  						
 							if (fp.exists()) {
 								result = fp.readToString();	
 								
 								if(result != null && !result.equals(""))
 									returnVars.put(workspaceFile.buildVariable, result);
 							}
 						} 
 	  					catch (IOException e) {
 	  						
 							LOGGER.log(Level.SEVERE, "In CommonUtil.processReportData() non-pipeline IOException : " + e.toString());
 						} 
 	  					catch (InterruptedException e) {
 	  						
 							LOGGER.log(Level.SEVERE, "In CommonUtil.processReportData() non-pipeline InterruptedException : " + e.toString());
 						}
 	 	 		    	
 	  		    	}
 	  		    	else {
 	  		    		
 	 	 				File file = new File(ws + workspaceFile.filePath);
 	 	 				
 	 	 				if(file.exists()) {
 	 	 					
 	 	 					try { 	 					
 								returnVars.put(workspaceFile.buildVariable, FileUtils.readFileToString(file, "UTF-8"));
 							} 
 	 	 					catch (IOException e) {
 	 	 						
 								LOGGER.log(Level.SEVERE, "In CommonUtil.processReportData() non-pipeline" +e.toString());
 							}	
 	 	 				}
 	  		    	}
 		 		}
 		 		
 		 	} 
 		 	else {
 		 		
 		 		for(WorkspaceFile workspaceFile : workspaceFiles) {
 		 			
 		 			FlowExecution exec = getExecution(run); 
 		 			
 		 			if (exec==null) 
 		 				return null;
 		 			
 		 		    FlowGraphWalker w = new FlowGraphWalker(exec);
 			 		
 		 		    for (FlowNode n : w) {
 		 		    	
 			 		       if (n instanceof StepStartNode) {	
 			 		    	   
 			 		          for (Action action:n.getAllActions()) {	
 			 		        	  
 			 		        	  if (action instanceof org.jenkinsci.plugins.workflow.support.actions.WorkspaceActionImpl) { 
 			 		        		  
 			 		        		  FilePath fp = null;
 			 		        		  FilePath ws = ((WorkspaceActionImpl) action).getWorkspace();
 			 		        		  String node = ((WorkspaceActionImpl) action).getNode().toString();
 			 		        		  String workspace = ((WorkspaceActionImpl) action).getPath().toString();			 		        		  
 			 		        		  
 			 		        		  if (ws.isRemote()) {	
 			 		        			  
 			 		        				Channel channel = (Channel) ws.getChannel();
 			 		        				fp = new FilePath(channel,ws + workspaceFile.filePath);
 			 		        				
 			 		        		  }	
 			 		        		  else {
 			 		        			  
 			 		        			  	fp = new FilePath(new File(ws + workspaceFile.filePath)); 
 			 		        		  }
 			 		        		  
 			 		        		  try {
 			 		        			  
 				 							if (fp.exists()) {
 				 								
 				 								result = fp.readToString();
 				 								
 												if(result !=null && !result.equals(""))
 													returnVars.put(workspaceFile.buildVariable, result);
 				 							}		 				 		    
 			 		        		  } 
 			 		        		  catch (IOException | InterruptedException e) {
 			 		        			  
 			 		        			  	LOGGER.log(Level.SEVERE, "In CommonUtil.processReportData() pipeline" +  e.toString());
 			 		        		  }			 		        		  
 			 		        	  }			 		        	  
 			 		          }       
 			 		      }
 		 		    }
 		 		}
 		 	}
 		 	
 	  		return returnVars; 			
 		}
 		
 		return null;	 	
     }	
	
	/**
	 * Removes the empty elements.
	 *
	 * @param workspaceFiles the workspace files
	 * @return the list
	 */
	private static List<WorkspaceFile> removeEmptyElements(List<WorkspaceFile> workspaceFiles) {		
		
		List<WorkspaceFile> processedWorkspaceFiles = new ArrayList<WorkspaceFile>();
			
		for(WorkspaceFile workspaceFile : workspaceFiles) {
 			
 			if(StringUtils.isNotBlank(workspaceFile.buildVariable) && StringUtils.isNotBlank(workspaceFile.filePath)) {
 	 			
 				processedWorkspaceFiles.add(workspaceFile);
 				
 				LOGGER.log(Level.FINEST, "In CommonUtil.removeEmptyElements() Workspace File Added: " + workspaceFile.buildVariable + " | File Path: " + workspaceFile.filePath);
 			}
 		} 				
		
		return processedWorkspaceFiles;		
	}

	
     /**
      * Process env vars.
      *
      * @param run the run
      * @param envVars the env vars
      * @return the env vars
      */
    public static EnvVars processEnvVars(Run run, EnvVars envVars) 
 	{ 
 		EnvVars returnVars = new EnvVars();
 		
 		for (Map.Entry<String, String> entry : envVars.entrySet()) 
 		{ 
 			try 
 			{ 
 				if(StringUtils.isNotBlank(entry.getKey())  && !entry.getKey().contains(".")) {
 					
 					if(StringUtils.isBlank(entry.getValue()))
 						returnVars.put(entry.getKey(), "");
 					else
 						returnVars.put(entry.getKey(), entry.getValue());						
 				}					 				 
 			} 
 			catch(NullPointerException e) { 
 				
 				LOGGER.log(Level.SEVERE, "Removed null value"); 
 			} 
 		}  	
  
 		return returnVars; 
 	}
          
  
  /**
   * The Class ReadFileRemote.
   */
  private static class ReadFileRemote implements FileCallable <String> {
	  
      /** The Constant serialVersionUID. */
      private static final long serialVersionUID = 1L;
      
      /**
       * Invoke.
       *
       * @param f the f
       * @param channel the channel
       * @return the string
       */
      /* (non-Javadoc)
       * @see hudson.FilePath.FileCallable#invoke(java.io.File, hudson.remoting.VirtualChannel)
       */
      public String invoke(File f, VirtualChannel channel) {
    	  
    	  try {
    		  
	    	  if (f.getAbsoluteFile().exists()){
	    		 
	              return FileUtils.readFileToString(f, "UTF-8");
	          } 
	    	  else {
	              
	    		  return "";
	          }
    	  }
    	  catch (Exception e) {
    		  
    		  LOGGER.log(Level.SEVERE, e.toString());
    	  }
    	  
          return "";
      }
      
      /**
       * Check roles.
       *
       * @param checker the checker
       * @throws SecurityException the security exception
       */
      /* (non-Javadoc)
       * @see org.jenkinsci.remoting.RoleSensitive#checkRoles(org.jenkinsci.remoting.RoleChecker)
       */
      public void checkRoles(RoleChecker checker) throws SecurityException {   

      }
  }
  
	/**
	 * Gets the job cause.
	 *
	 * @param cause the cause
	 * @return the job cause
	 */
	public static String getJobCause(Cause cause) { 
		
		String id = OneTConstants.JOB_CAUSE_UNKNOWN; 
		
		try { 

			if(cause instanceof UserIdCause) { 
				
				UserIdCause userIdCause = (UserIdCause) cause; 
				
				if(StringUtils.isBlank(userIdCause.getUserId())) 
					id = OneTConstants.JOB_CAUSE_ANONYMOUS; 
				else 
					id = userIdCause.getUserId(); 				
			} 
			else if(cause instanceof TimerTriggerCause) { 
				
				TimerTriggerCause timeTriggerCause = (TimerTriggerCause) cause; 				
				id = timeTriggerCause.getShortDescription();				
			} 
			else if(cause instanceof SCMTriggerCause) { 
				
				SCMTriggerCause scmTriggerCause = (SCMTriggerCause) cause; 
				id = scmTriggerCause.getShortDescription(); 
			} 
			else if(cause instanceof UpstreamCause) { 
				
				UpstreamCause upstreamCause = (UpstreamCause) cause; 
				id = upstreamCause.getUpstreamProject();				
			} 
			else if(cause instanceof RemoteCause) { 
				
				RemoteCause remoteCause = (RemoteCause) cause; 				
				id = remoteCause.getShortDescription();
				
			}  
		} 
		catch(NullPointerException e) { 
			// Do nothing 
		} 

		return id; 
	}
	
	/**
	 * Decode string.
	 *
	 * @param value the value
	 * @return the string
	 */
	public static String decodeString(String value) {
		
		try {
			return URLDecoder.decode(value,"UTF-8");				
		}
		catch(Exception e){
			LOGGER.log(Level.WARNING, OneTConstants.ONET_LOG + "Exception: " + e.getMessage());
		}
		
		return value;
	}
	
	/**
	 * Check configuration.
	 *
	 * @return true, if successful
	 */
	public static boolean checkConfiguration() {
		
		boolean returnValue = true;
			
		if(StringUtils.isBlank(OneTConfiguration.DESCRIPTOR.host) || !OneTConfiguration.DESCRIPTOR.host.contains(":")) {
			LOGGER.log(Level.SEVERE, "One T host is not configured");
			returnValue = false;
		}
		if(StringUtils.isBlank(OneTConfiguration.DESCRIPTOR.credentialsId)) {
			LOGGER.log(Level.SEVERE, "One T Credentials ID is not configured");
			returnValue = false;
		}
		if(StringUtils.isBlank(OneTConfiguration.DESCRIPTOR.url)) {
			LOGGER.log(Level.SEVERE, "One T URL is not configured");
			returnValue = false;
		}		
		
		return returnValue;
	}
	
	/**
	 * Lookup credentials.
	 *
	 * @param credentialId the credential id
	 * @return the username password credentials impl
	 */
	public static UsernamePasswordCredentialsImpl lookupCredentials(String credentialId) {	
		
		return (credentialId == null) ? null : CredentialsMatchers.firstOrNull(CredentialsProvider.lookupCredentials(UsernamePasswordCredentialsImpl.class, ACL.SYSTEM),CredentialsMatchers.withId(credentialId));
	}
	
	/**
	 * Nullify quietly.
	 *
	 * @param objects the objects
	 */
	public static void nullifyQuietly(Object ...objects ) {
		
		for (Object object : objects) {
			
			if(object != null)
				object = null;
		}		
	}

	/**
	 * Sets the conversation ID parameter.
	 *
	 * @param run the new conversation ID parameter
	 */
	public static void setConversationIDParameter(Run run) {		
		
		StringParameterValue parameterValue = null;
		List<ParameterValue> parametersValueList = null;
		ParametersAction currentParametersAction = null;
		ParametersAction newParametersAction = null;
		ParametersDefinitionProperty currentParams = null;
		List<ParameterDefinition> newParams = null;		

		try {
			
			parameterValue = new StringParameterValue("CONVERSATION_ID", run.getAction(ConversationIDAction.class).getID());
			parametersValueList = new ArrayList<ParameterValue>();				
			parametersValueList.add(parameterValue);
			currentParametersAction = run.getAction(ParametersAction.class);	

			if (currentParametersAction != null) {
				
				run.getActions().remove(currentParametersAction);
				newParametersAction = currentParametersAction.createUpdated(parametersValueList);
			} 
			else {
				
				newParametersAction = new ParametersAction(parametersValueList);
			}
			
			run.getActions().add(newParametersAction);			
			run.getParent().removeAction(newParametersAction);
		}
		catch(Exception e) {
			
			LOGGER.log(Level.SEVERE, OneTConstants.ONET_LOG + "Exception: " + e.getMessage());			
		}
		finally {
						
			nullifyQuietly(parameterValue,
						   parametersValueList,
						   currentParametersAction,
						   newParametersAction,
						   currentParams,
						   newParams);			
		}		
	}
	
	/**
	 * Gets the scmjson.
	 *
	 * @param run the run
	 * @return the scmjson
	 */
	public static String getSCMJSON(Run run) {
		
		ObjectMapper objectMapper = null;	

		try {

			objectMapper = new ObjectMapper();

			return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(getSCMs(run));
		}
		catch(Exception e) {

			return e.toString();
		}
		finally {

			nullifyQuietly(objectMapper);
		}				
	}
	
    /**
     * Gets the SC ms.
     *
     * @param run the run
     * @return the SC ms
     */
    public static Map<String,List> getSCMs(Run run) {
    	
    	Map<String,List> scmMap = null;
        List<SCMBase> runList = null;
        List<SCMBase> projectList = null;
        List<BuildData> runs = null;
        List<SCM> projects = null;
        SCMGit runGit = null;
        SCMGit projectGit = null;
        SCMGit scmGit = null;
    	
    	try {
    		
	    		scmMap = new HashMap<String,List>();
	    		runList = new ArrayList<SCMBase>();
	    		projectList = new ArrayList<SCMBase>();
	    		
	    		if(run instanceof WorkflowRun) {
	
	                runs = ((WorkflowRun) run).getActions(BuildData.class);
		                
	                for(BuildData buildData : runs) {
	                	
                		runGit = new SCMGit();

                        runGit.setName(buildData.getLastBuiltRevision().toString());
                        runGit.setRevision(buildData.getLastBuiltRevision().getSha1String());
                        runGit.setBranches(buildData.getLastBuiltRevision().getBranches());
                        runGit.setRemoteUrls(buildData.getRemoteUrls());

                        runList.add(runGit);
                        
                        runGit = null;
	                }
	                
	                scmMap.put("run", runList);
	                
	                
	                projects = ((WorkflowRun) run).getSCMs();
		                
	                for(SCM scm : projects) {
	
                        if(scm.getType().equals("hudson.plugins.git.GitSCM")) {

                            for(UserRemoteConfig userRomoteConfig : ((GitSCM) scm).getUserRemoteConfigs()) {
                            	
                            	projectGit = new SCMGit();

                                projectGit.setName(userRomoteConfig.getName());
                                projectGit.setRevision(userRomoteConfig.getCredentialsId());                             
                                Set<String> urls = new HashSet<String>();                                            
                                urls.add(userRomoteConfig.getUrl());
                                projectGit.setRemoteUrls(urls);
                                
                                projectList.add(projectGit);
                                
                                projectGit = null;
                            }
                        }
	                }
	                
	                scmMap.put("project", projectList);
		        }
		        else {
		
		            if(run.getAction(BuildData.class) != null) {
		
		                    for(BuildData buildData : run.getActions(BuildData.class)) {
		
		                            scmGit = new SCMGit();
		
		                            scmGit.setName(buildData.getLastBuiltRevision().toString());
		                            scmGit.setRevision(buildData.getLastBuiltRevision().getSha1String());
		                            scmGit.setBranches(buildData.getLastBuiltRevision().getBranches());
		                            scmGit.setRemoteUrls(buildData.getRemoteUrls());
		
		                            projectList.add(scmGit);
		                    }
		            }
		            
		            scmMap.put("nonPipeline", projectList);
		        }
	    		
	    		return scmMap;
    	}
    	catch(Exception e) {
    		
    		LOGGER.log(Level.SEVERE, "Exception in SCMs: " + e.getMessage());	
    	}
    	finally {
    		
    		nullifyQuietly(scmMap,
    					   projectList,
    					   runs,
    					   projects,
    					   runGit,
    					   projectGit,
    					   scmGit);
    	} 
    	
    	return null;
    }
    
    /**
     * Gets the plugins.
     *
     * @return the plugins
     */
    public static Map<String, String> getPlugins() {
    	
    	Map<String, String> pluginMap = new HashMap<String, String>();
    	    	
    	for(PluginWrapper pluginWrapper : Jenkins.getInstanceOrNull().getPluginManager().getPlugins()) {
    		
    		pluginMap.put(pluginWrapper.getDisplayName(), pluginWrapper.getVersion());    		
    	}
    	
    	return pluginMap;
    }
    
    /**
     * Gets the file path.
     *
     * @param file the file
     * @return the file path
     */
    public static String getFilePath(File file) {    	
    	
    	try {
    		
    		return file.getCanonicalPath();    		
    	}
    	catch(IOException e) {
    		
    		return "N/A";
    	}    	
    }
    
    /**
     * Gets the file size.
     *
     * @param file the file
     * @return the file size
     */
    public static String getFileSize(File file) {
    	
    	return Long.toString(file.length());
    }
    
    /**
     * Gets the file date.
     *
     * @param file the file
     * @return the file date
     */
    public static String getFileDate(File file) {
    	
    	BasicFileAttributes attribute;
    	
    	try {
    		
    		attribute = Files.readAttributes(file.toPath(), BasicFileAttributes.class);
    		
    		return attribute.creationTime().toString();
		} 
    	catch (IOException e) {
			
    		return "N/A";
		}    	
    }
    
    /**
     * Gets the checksums.
     *
     * @param run the run
     * @param listener the listener
     * @return the checksums
     */
    public static Set<Artifact> getChecksums(Run run, TaskListener listener) {
    	
    	listener.getLogger().println(OneTConstants.ONET_LOG + "Starting Checksums");    	
    	
    	String[] extensions = OneTConfiguration.DESCRIPTOR.checksumFilter.split(",");    	
    	Set<Artifact> artifacts = new HashSet<Artifact>();
    	FilePath workspace = null;
    	
    	if (run instanceof AbstractBuild) {
    		
    		AbstractBuild<?, ?> build = (AbstractBuild<?, ?>) run;
    		
    		workspace = build.getWorkspace();
        } 
		else if(run instanceof WorkflowRun) {
			
			WorkflowRun workflowRun = null; 			
			FlowExecution execution = null;
			FlowGraphWalker flowGraphWalker = null;
			WorkspaceAction workspaceAction = null;
			
			try {
				
				workflowRun = (WorkflowRun) run;
				execution = workflowRun.getExecution();
				flowGraphWalker = new FlowGraphWalker(execution);
				
				for (FlowNode flowNode : flowGraphWalker) {
					
					if (flowNode instanceof StepStartNode) {
						
						workspaceAction = flowNode.getAction(WorkspaceAction.class);
				    	
						if (workspaceAction != null) {
							workspace = workspaceAction.getWorkspace();	
							break;
						}  
				    }
				}
			}
			catch(Exception e) {
				
				LOGGER.log(Level.SEVERE, "Exception in Checkesums: " + e.getMessage());
			}
			finally {
				
				nullifyQuietly(workflowRun,
							   execution,
							   flowGraphWalker,
							   workspaceAction);
			}		
        }

    	if(workspace != null) {
     		
    		 InputStream in = null;
    		 Artifact artifact = null;
    		 
    		 try {
    			    			
				Collection<FilePath> filePaths = FilePathUtils.listFiles(workspace, extensions, true);	
			    			
    			for(FilePath filePath : filePaths) {
    				
    				if(filePath.toVirtualFile().isFile() && filePath.toVirtualFile().lastModified() > run.getStartTimeInMillis()) {
    				
	    				in = filePath.read();
	    				
	    				artifact = new Artifact();        					
						artifact.setName(filePath.getName());
						artifact.setChecksum(DigestUtils.sha256Hex(in));        					
						artifacts.add(artifact);
						
						listener.getLogger().println(OneTConstants.ONET_LOG + "Added artifact: " + artifact.getName()  + " | " + artifact.getChecksum());
	    				
	    				if(in != null) {
	    					
	    					try {
	    						
	    						in.close();
	    					} 
	    					catch (IOException e) {} 
	    				}	
	    			}    				
    			}    			
    		 }
    		 catch(Exception e) {
    			
    			 listener.getLogger().println(OneTConstants.ONET_LOG + e.getMessage());    			
    		 }
    		 finally {   				
    			
    			 nullifyQuietly(in,
    						   	artifact);
    		 }
    		 
    	}
    	else {
    		
    		listener.getLogger().println(OneTConstants.ONET_LOG + "Workspace is null, checksum aborted"); 
    	}
    	
    	return artifacts;    	
    }
}
