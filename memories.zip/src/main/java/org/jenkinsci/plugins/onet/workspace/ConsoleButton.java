package org.jenkinsci.plugins.onet.workspace;

import org.kohsuke.stapler.DataBoundConstructor;

// TODO: Auto-generated Javadoc
/**
 * The Class ConsoleButton.
 */
public class ConsoleButton {
	
	/**
	 * Instantiates a new console button.
	 *
	 * @param html the html
	 * @param button the button
	 * @param search the search
	 */
	@DataBoundConstructor
	public ConsoleButton(String html, String button, String search) { 
		
		this.html = html;
		this.button = button;
		this.search = search;
    }
	
	/** The html. */
	public String html;
	
	/** The button. */
	public String button;
	
	/** The search. */
	public String search;

}
