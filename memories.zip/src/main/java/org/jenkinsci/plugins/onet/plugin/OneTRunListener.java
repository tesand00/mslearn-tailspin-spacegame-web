package org.jenkinsci.plugins.onet.plugin;

import java.io.IOException;
import java.io.Serializable;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.CheckForNull;
import javax.annotation.Nonnull;

import org.apache.commons.lang.StringUtils;
import org.jenkinsci.plugins.onet.action.ArtifactAction;
import org.jenkinsci.plugins.onet.action.ConversationIDAction;
import org.jenkinsci.plugins.onet.action.IdentifierAction;
import org.jenkinsci.plugins.onet.configuration.OneTConfiguration;
import org.jenkinsci.plugins.onet.constants.OneTConstants;
import org.jenkinsci.plugins.onet.model.Application;
import org.jenkinsci.plugins.onet.model.Body;
import org.jenkinsci.plugins.onet.model.EventData;
import org.jenkinsci.plugins.onet.model.FlowNodeData;
import org.jenkinsci.plugins.onet.model.Meta;
import org.jenkinsci.plugins.onet.model.OneTRequest;
import org.jenkinsci.plugins.onet.model.Runtime;
import org.jenkinsci.plugins.onet.model.Stage;
import org.jenkinsci.plugins.onet.model.Step;
import org.jenkinsci.plugins.onet.model.Transaction;
import org.jenkinsci.plugins.onet.processor.APIProcessor;
import org.jenkinsci.plugins.onet.util.CommonUtil;
import org.jenkinsci.plugins.onet.workspace.ConsoleButton;
import org.jenkinsci.plugins.workflow.actions.WorkspaceAction;
import org.jenkinsci.plugins.workflow.cps.CpsFlowExecution;
import org.jenkinsci.plugins.workflow.cps.nodes.StepStartNode;
import org.jenkinsci.plugins.workflow.flow.FlowExecution;
import org.jenkinsci.plugins.workflow.flow.FlowExecutionOwner;
import org.jenkinsci.plugins.workflow.graph.FlowGraphWalker;
import org.jenkinsci.plugins.workflow.graph.FlowNode;
import org.jenkinsci.plugins.workflow.job.WorkflowRun;
import org.kohsuke.stapler.DataBoundConstructor;

import com.cloudbees.workflow.flownode.FlowNodeUtil;
import com.cloudbees.workflow.rest.external.AtomFlowNodeExt;
import com.cloudbees.workflow.rest.external.StageNodeExt;

import hudson.Extension;
import hudson.Launcher;
import hudson.console.ExpandableDetailsNote;
import hudson.model.AbstractBuild;
import hudson.model.Action;
import hudson.model.BuildListener;
import hudson.model.Environment;
import hudson.model.Result;
import hudson.model.Run;
import hudson.model.TaskListener;
import hudson.model.listeners.RunListener;
import jenkins.model.Jenkins;


@Extension
public class OneTRunListener extends RunListener<Run> implements Serializable{
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = Logger.getLogger(OneTRunListener.class.getName());
		
	@DataBoundConstructor
    public OneTRunListener(){}
	
	/* (non-Javadoc)
	 * @see hudson.model.listeners.RunListener#setUpEnvironment(hudson.model.AbstractBuild, hudson.Launcher, hudson.model.BuildListener)
	 */
	@Override
	public Environment setUpEnvironment(@Nonnull AbstractBuild abstractBuild, @Nonnull Launcher launcher, @Nonnull BuildListener listener) throws IOException, InterruptedException {
		
		return new Environment() {};	
	}

			
	/* (non-Javadoc)
	 * @see hudson.model.listeners.RunListener#onStarted(hudson.model.Run, hudson.model.TaskListener)
	 */
	@Override
	public void onStarted(Run run, TaskListener listener) {
		
		if(CommonUtil.doRecord(run)) {
						
			listener.getLogger().println(OneTConstants.ONET_LOG + OneTConstants.MESSAGE_RUN_STARTED + CommonUtil.decodeString(run.getParent().getFullName()));			
					
			if(run.getActions(ConversationIDAction.class) != null &&
		       run.getActions(ConversationIDAction.class).isEmpty()) {
				
				run.addAction(new ConversationIDAction(UUID.randomUUID().toString()));				
			}
			
			if(OneTConfiguration.DESCRIPTOR.isConversationId())				
				CommonUtil.setConversationIDParameter(run);	
			
			if(run.getActions(ArtifactAction.class) != null && 
			   run.getActions(ArtifactAction.class).isEmpty()) {
				
				run.addAction(new ArtifactAction());
			}
									
			APIProcessor apiProcessor = new APIProcessor();
			OneTRequest oneTRequest = new OneTRequest();
			Transaction transaction = new Transaction();
			Runtime runtime = new Runtime();
			Application application = new Application();
			Body body = new Body();		
			EventData eventdata = new EventData();
			Meta meta = new Meta();
			String timestamp = CommonUtil.getGMTSystemTime();
			
			try {	
				
				runtime.setIP(InetAddress.getLocalHost().getHostAddress());
			}
			catch(UnknownHostException e) {
				
				LOGGER.log(Level.WARNING, "Unable to set IP address");
				runtime.setIP("");
			}
			
			try {
				runtime.setHostName(new URL(Jenkins.get().getRootUrl()).getHost());
			}
			catch(MalformedURLException e) {
				LOGGER.log(Level.WARNING, "Unable to set Host");
				runtime.setHostName("");
			}
			
			if(OneTConfiguration.DESCRIPTOR.identifier)
				run.addAction(new IdentifierAction(apiProcessor.getIdentifier(run)));
			
			runtime.setInstance(Jenkins.get().getRootUrl());
			runtime.setClusterName("");
			runtime.setNamespace(CommonUtil.getFolderName(run));				
			runtime.setImage("");
			
			if(OneTConfiguration.DESCRIPTOR.identifier)
				runtime.setIdentifier(run.getAction(IdentifierAction.class).getID());			
			
			meta.setBuildType(run.getParent().getClass().getName());			
			meta.setBuildStartedBy(CommonUtil.getStartedBy(run));			
			meta.setBuildUser(CommonUtil.getUserId(run));	
			meta.setPluginVersion(CommonUtil.getPluginVersion());
			
			application.setDeploymentUnitName("JENKINS");
			application.setMOTSApplicationAcronym("SDT-JENKINS");	
			
			if(run.getNumber() > 0)
				meta.setBuildNumber(run.getNumber());						
			
			if(StringUtils.isNotBlank(CommonUtil.decodeString(run.getParent().getFullName())))
				meta.setJobName(CommonUtil.decodeString(run.getParent().getFullName()));
						
			if(StringUtils.isNotBlank(Jenkins.get().getRootUrl()))
				meta.setInstanceUrl(Jenkins.get().getRootUrl());
			
			if(StringUtils.isNotBlank(Jenkins.get().getVersion().toString()))
				meta.setInstanceVersion(Jenkins.get().getVersion().toString());
			
			meta.setBuildVariables(CommonUtil.processEnvVars(run, listener));			            
            meta.setDescription("JenkinsBuildStart");
            
			eventdata.setMessageName("JenkinsBuildStart");
			eventdata.setMessageType("eventdata");
			eventdata.setMeta(meta);
			
			body.setEventdata(eventdata);
			body.setRealtime(OneTConfiguration.DESCRIPTOR.isRealtime());			
			
			transaction.setTransactionId(run.getAction(ConversationIDAction.class).getID() + "-" + timestamp);
			transaction.setConversationId(run.getAction(ConversationIDAction.class).getID());
			transaction.setReceivedTimestamp(timestamp);
			
			oneTRequest.setLogType("Trace");
			oneTRequest.setLogLevel("Trace");
			oneTRequest.setLogTimestamp(timestamp);
			oneTRequest.setBody(body);
			oneTRequest.setTransaction(transaction);
			oneTRequest.setRuntime(runtime);
			oneTRequest.setApplication(application);
			
			listener.getLogger().println(apiProcessor.postEvent(oneTRequest, "Build for " + meta.getJobName() + " started with conversation ID: " 
																											  + run.getAction(ConversationIDAction.class).getID()));
						
			CommonUtil.nullifyQuietly(apiProcessor,
					  				  oneTRequest,
					  				  transaction,
					  				  runtime,
					  				  application,
					  				  body,		
					  				  eventdata,
					  				  meta,
					  				  timestamp);			
		}
	}
	
	/* (non-Javadoc)
	 * @see hudson.model.listeners.RunListener#onCompleted(hudson.model.Run, hudson.model.TaskListener)
	 */
	@Override
    public void onCompleted(Run run, TaskListener listener) {
		
		if(CommonUtil.doRecord(run)) {
		
			APIProcessor apiProcessor = new APIProcessor();	
			OneTRequest oneTRequest = new OneTRequest();
			Transaction transaction = new Transaction();
			Runtime runtime = new Runtime();
			Application application = new Application();
			Body body = new Body();		
			EventData eventdata = new EventData();
			Meta meta = new Meta();						
			String timestamp = CommonUtil.getGMTSystemTime();
			
			try {				
				runtime.setIP(InetAddress.getLocalHost().getHostAddress());
			}
			catch(UnknownHostException e) {
				LOGGER.log(Level.WARNING, "Unable to set IP address");
				runtime.setIP("");
			}
			
			try {
				runtime.setHostName(new URL(Jenkins.get().getRootUrl()).getHost());
			}
			catch(MalformedURLException e) {
				LOGGER.log(Level.WARNING, "Unable to set Host");
				runtime.setHostName("");
			}
			
			runtime.setInstance(Jenkins.get().getRootUrl());
			runtime.setClusterName("");
			runtime.setNamespace(CommonUtil.getFolderName(run));
			runtime.setImage("");
			
			if(OneTConfiguration.DESCRIPTOR.identifier)
				runtime.setIdentifier(run.getAction(IdentifierAction.class).getID());
			
			meta.setBuildType(run.getParent().getClass().getName());			
			meta.setBuildStartedBy(CommonUtil.getStartedBy(run));			
			meta.setBuildUser(CommonUtil.getUserId(run));	
			meta.setPluginVersion(CommonUtil.getPluginVersion());
			meta.setScms(CommonUtil.getSCMs(run));							
			
			run.getAction(ArtifactAction.class).addArtifacts(CommonUtil.getChecksums(run, listener));			
			meta.setArtifacts(run.getAction(ArtifactAction.class).getArtifacts());
						
			application.setDeploymentUnitName("JENKINS");
			application.setMOTSApplicationAcronym("SDT-JENKINS");	
			
			if(run.getNumber() > 0)
				meta.setBuildNumber(run.getNumber());
									
			if(StringUtils.isNotBlank(CommonUtil.decodeString(run.getParent().getFullName())))
				meta.setJobName(CommonUtil.decodeString(run.getParent().getFullName()));
			
			if(StringUtils.isNotBlank(Jenkins.get().getRootUrl()))
				meta.setInstanceUrl(Jenkins.get().getRootUrl());
			
			if(StringUtils.isNotBlank(Jenkins.get().getVersion().toString()))
				meta.setInstanceVersion(Jenkins.get().getVersion().toString());									
					
			meta.setBuildDuration(run.getDuration());
			
			if(run.getResult() != null && StringUtils.isNotBlank(run.getResult().toString()))
				meta.setBuildResult(run.getResult().toString());
			else
				meta.setBuildResult("N/A");
			
			try{			
				if(OneTConfiguration.DESCRIPTOR.maxLogSize > 0) {				
					meta.setBuildLog(run.getLog(OneTConfiguration.DESCRIPTOR.maxLogSize));
				}
			}
			catch(Exception e) {
				LOGGER.log(Level.SEVERE, OneTConstants.ONET_LOG + "Exception setting max log size: " + e.getMessage());		
			}
			
			try {  
				meta.setConfigFile(run.getParent().getConfigFile().asString());
			}
			catch(Exception e) {
				LOGGER.log(Level.SEVERE, OneTConstants.ONET_LOG + "Exception getting configuration file: " + e.getMessage());	
			}
			
			if(OneTConstants.WORKFLOW_JOB_CLASS.equals(run.getParent().getClass().getName()) ){   
				
				List<FlowNode> listFlowNode = FlowNodeUtil.getStageNodes(getExecution(run));
				FlowNodeData flowNodeData = retrieveFlowNodeData(listFlowNode);	
				meta.setPipelineData(flowNodeData);
			}
			
			meta.setBuildVariables(CommonUtil.processEnvVars(run, listener));
			meta.setFolderVariables(CommonUtil.processFolderVars(run, listener));
            meta.setDescription("JenkinsBuildCompleted");
            meta.setAgents(getAgents(run));
            
			eventdata.setMessageName("JenkinsBuildCompleted");
			eventdata.setMessageType("eventdata");
			eventdata.setMeta(meta);
			
			if(CommonUtil.processReportData(run) != null)
				meta.setReportVariables(CommonUtil.processReportData(run));	
			
			body.setEventdata(eventdata);
			body.setRealtime(OneTConfiguration.DESCRIPTOR.isRealtime());
            
			transaction.setTransactionId(run.getAction(ConversationIDAction.class).getID() + "-" + timestamp);
			transaction.setConversationId(run.getAction(ConversationIDAction.class).getID());
			transaction.setReceivedTimestamp(timestamp);
			
			oneTRequest.setLogType("Trace");
			oneTRequest.setLogLevel("Trace");
			oneTRequest.setLogTimestamp(timestamp);
			oneTRequest.setBody(body);
			oneTRequest.setTransaction(transaction);
			oneTRequest.setRuntime(runtime);
			oneTRequest.setApplication(application);
						
			if(run.getResult().isWorseOrEqualTo(Result.FAILURE)) {				
				
				for(ConsoleButton consoleButton : OneTConfiguration.DESCRIPTOR.getConsoleButtons()) {
					
					try {
					
						if(StringUtils.isBlank(consoleButton.search) || run.getLog(OneTConfiguration.DESCRIPTOR.maxLogSize).toString().contains(consoleButton.search))
							listener.getLogger().println(ExpandableDetailsNote.encodeTo(consoleButton.button, consoleButton.html));
							
					}
					catch(Exception e) {
						LOGGER.log(Level.WARNING, "Unable to read log for Console Link: " + consoleButton.button);
					}
				}
			}
			
			listener.getLogger().println(apiProcessor.postEvent(oneTRequest, "Build for " + meta.getJobName() + " completed with conversation ID: " 
																											  + run.getAction(ConversationIDAction.class).getID()));
			
			CommonUtil.nullifyQuietly(apiProcessor,
	  				  				  oneTRequest,
	  				  				  transaction,
	  				  				  runtime,
	  				  				  application,
	  				  				  body,		
	  				  				  eventdata,
	  				  				  meta,
	  				  				  timestamp);	
		}
    }
	
	
	/* (non-Javadoc)
	 * @see hudson.model.listeners.RunListener#onFinalized(hudson.model.Run)
	 */
	@Override 
    public void onFinalized(Run run) { 
		
		if(CommonUtil.doRecord(run)) {
			
			APIProcessor apiProcessor = new APIProcessor();	
			OneTRequest oneTRequest = new OneTRequest();
			Transaction transaction = new Transaction();
			Runtime runtime = new Runtime();
			Application application = new Application();
			Body body = new Body();		
			EventData eventdata = new EventData();
			Meta meta = new Meta();			
			String timestamp = CommonUtil.getGMTSystemTime();
			
			runtime.setInstance(Jenkins.get().getRootUrl());
			runtime.setClusterName("");
			runtime.setNamespace(CommonUtil.getFolderName(run));
			runtime.setImage("");
			
			if(OneTConfiguration.DESCRIPTOR.identifier)
				runtime.setIdentifier(run.getAction(IdentifierAction.class).getID());
			
			meta.setBuildType(run.getParent().getClass().getName());			
			meta.setBuildStartedBy(CommonUtil.getStartedBy(run));			
			meta.setBuildUser(CommonUtil.getUserId(run));	
			meta.setPluginVersion(CommonUtil.getPluginVersion());
			
			application.setDeploymentUnitName("JENKINS");
			application.setMOTSApplicationAcronym("SDT-JENKINS");	
			
			if(run.getNumber() > 0)
				meta.setBuildNumber(run.getNumber());
									
			if(StringUtils.isNotBlank(CommonUtil.decodeString(run.getParent().getFullName())))
				meta.setJobName(CommonUtil.decodeString(run.getParent().getFullName()));
			
			if(StringUtils.isNotBlank(Jenkins.get().getRootUrl()))
				meta.setInstanceUrl(Jenkins.get().getRootUrl());
			
			if(StringUtils.isNotBlank(Jenkins.get().getVersion().toString()))
				meta.setInstanceVersion(Jenkins.get().getVersion().toString());
			
			meta.setBuildDuration(run.getDuration());
			
			if(run.getResult() != null && StringUtils.isNotBlank(run.getResult().toString()))
				meta.setBuildResult(run.getResult().toString());
			else
				meta.setBuildResult("N/A");
			
			if(CommonUtil.processReportData(run) != null)
				meta.setReportVariables(CommonUtil.processReportData(run));			
			
			try{			
				if(OneTConfiguration.DESCRIPTOR.maxLogSize > 0) {				
					meta.setBuildLog(run.getLog(OneTConfiguration.DESCRIPTOR.maxLogSize));				
				}
			}
			catch(Exception e) {
				LOGGER.log(Level.SEVERE, OneTConstants.ONET_LOG + "Exception setting max log size: " + e.getMessage());		
			}
			
			meta.setDescription("JenkinsBuildFinalized");
			
			eventdata.setMessageName("JenkinsBuildFinalized");
			eventdata.setMessageType("eventdata");
			eventdata.setMeta(meta);
			
			body.setEventdata(eventdata);
			body.setRealtime(OneTConfiguration.DESCRIPTOR.isRealtime());
            
			transaction.setTransactionId(run.getAction(ConversationIDAction.class).getID() + "-" + timestamp);
			transaction.setConversationId(run.getAction(ConversationIDAction.class).getID());
			transaction.setReceivedTimestamp(timestamp);
			
			oneTRequest.setLogType("Trace");
			oneTRequest.setLogLevel("Trace");
			oneTRequest.setLogTimestamp(timestamp);
			oneTRequest.setBody(body);
			oneTRequest.setTransaction(transaction);
			oneTRequest.setRuntime(runtime);
			oneTRequest.setApplication(application);
						
			LOGGER.log(Level.SEVERE, (apiProcessor.postEvent(oneTRequest, "Build for " + meta.getJobName() + " postbuild data upload completed with conversation ID: " 
															+ run.getAction(ConversationIDAction.class).getID())));
												
			CommonUtil.nullifyQuietly(apiProcessor,	
	  				  				  oneTRequest,
	  				  				  transaction,
	  				  				  runtime,
	  				  				  application,
	  				  				  body,		
	  				  				  eventdata,
	  				  				  meta,
	  				  				  timestamp);	
		}
		
	}
	
	/**
	 * Gets the execution.
	 *
	 * @param run the run
	 * @return the execution
	 */
	private @CheckForNull static CpsFlowExecution getExecution(Run run) {
		
        FlowExecutionOwner owner = ((FlowExecutionOwner.Executable) run).asFlowExecutionOwner();
        
        if (owner == null) 
            return null;        
        
        FlowExecution exec = owner.getOrNull();
        
        return exec instanceof CpsFlowExecution ? (CpsFlowExecution) exec : null;
    }
	
	/**
	 * Retrieve flow node data.
	 *
	 * @param listFlowNode the list flow node
	 * @return the flow node data
	 */
	private FlowNodeData retrieveFlowNodeData(List<FlowNode> listFlowNode) {

		FlowNodeData flowNodeData = new FlowNodeData();
		List<Stage> stages = new ArrayList<Stage>();
		List<Step> steps = null;
		Stage stage = null;
		Step step = null;				
		String script = null;
		
		for(FlowNode flowNode: listFlowNode) {	
			
			stage = new Stage();				
			stages.add(stage);																			
			steps = new ArrayList<Step>();
			script = ((CpsFlowExecution) flowNode.getExecution()).getScript().toString();
			
			for (Action action:flowNode.getAllActions()) {
				
				if ( action instanceof com.cloudbees.workflow.rest.endpoints.FlowNodeAPI) { 
					
					try {
						
						StageNodeExt sNode = (StageNodeExt)((com.cloudbees.workflow.rest.endpoints.FlowNodeAPI) action).doDescribe();
						
						if(sNode.getError()!=null)
							stage.setErrorMsg(sNode.getError().getMessage());
						else
							stage.setErrorMsg("");
												
			        	stage.setStatus(sNode.getStatus().toString());     	
						stage.setName(flowNode.getDisplayName());
						
						if (sNode.getDurationMillis()>0 && sNode.getDurationMillis()<360000000)   //0~100h
							stage.setDuration(sNode.getDurationMillis());										
						
						List<AtomFlowNodeExt> sfNodes = ((StageNodeExt)((com.cloudbees.workflow.rest.endpoints.FlowNodeAPI) action).doDescribe()).getStageFlowNodes();
			        	
			        	Iterator it = sfNodes.iterator();
			        	
			        	while (it.hasNext()){	
			        		
							AtomFlowNodeExt aNode = (AtomFlowNodeExt) it.next();	

							step = new Step();
							
		                  	if (aNode.getError()!=null) 		                  												
		                  		step.setLog(aNode.getError().getMessage());				                  						                  						                    	
		                    else if(aNode.getParameterDescription()!=null)
		                    	step.setLog(aNode.getParameterDescription());
		                    else 
		                    	step.setLog("");
		                    				                  	
							step.setName(aNode.getName().toString());
	                    	step.setStatus(aNode.getStatus().toString());
	                    	steps.add(step);	                    	
						}
			        	
			        	stage.setSteps(steps);
					} 
					catch (IOException e) {
						
						LOGGER.log(Level.SEVERE, "IOException " + e.getMessage());
					}
				} 
			}	
		} 
		
		flowNodeData.setStages(stages);
		flowNodeData.setScript(script);
		
		CommonUtil.nullifyQuietly(stages,
								  stage,
								  step,
								  script);								  
		
		return flowNodeData;
	}
	
	private List<String> getAgents(Run run) {
		
		List<String> agents = new ArrayList<String>();
		
		if(run instanceof WorkflowRun) {
			
            WorkflowRun workflowRun = (WorkflowRun) run;
            CpsFlowExecution exec = (CpsFlowExecution) workflowRun.getExecution();
            FlowGraphWalker w = new FlowGraphWalker(exec);
            
            for (FlowNode n : w) {
            	
                if (n instanceof StepStartNode) {
                	
                   WorkspaceAction action = n.getAction(WorkspaceAction.class);
                   
                   if (action != null) {
                	   
                      String node = action.getNode().toString();
                      agents.add(node);
                   }           
                }
            }

            if(agents.isEmpty())
               agents.add( "n/a");               
        } 
		else {
        	 agents.add(run.getExecutor().getCurrentExecutable().getParent().getLastBuiltOn().getNodeName());
        }
		
		return agents;		
	}

}
