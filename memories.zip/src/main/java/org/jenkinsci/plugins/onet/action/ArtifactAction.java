package org.jenkinsci.plugins.onet.action;

import java.util.HashSet;
import java.util.Set;

import org.jenkinsci.plugins.onet.model.Artifact;

import hudson.model.Action;

// TODO: Auto-generated Javadoc
/**
 * The Class ArtifactAction.
 */
public class ArtifactAction implements Action {
	
	/**
	 * Instantiates a new artifact action.
	 */
	public ArtifactAction() {
		
		if(artifacts == null)
			artifacts = new HashSet<Artifact>();
	}
		
	/** The artifacts. */
	private Set<Artifact> artifacts;
	
	/**
	 * Adds the artifact.
	 *
	 * @param artifact the artifact
	 */
	public void addArtifact(Artifact artifact) {
		
		artifacts.add(artifact);
	}
	
	/**
	 * Adds the artifacts.
	 *
	 * @param artifacts the artifacts
	 */
	public void addArtifacts(Set<Artifact> artifacts) {
		
		this.artifacts.addAll(artifacts);
	}

	/**
	 * Gets the artifacts.
	 *
	 * @return the artifacts
	 */
	public Set<Artifact> getArtifacts() {
		return artifacts;
	}

	/**
	 * Sets the artifacts.
	 *
	 * @param artifacts the new artifacts
	 */
	public void setArtifacts(Set<Artifact> artifacts) {
		this.artifacts = artifacts;
	}

	/**
	 * Gets the icon file name.
	 *
	 * @return the icon file name
	 */
	@Override
	public String getIconFileName() {
		return "document-properties.gif";
	}

	/**
	 * Gets the display name.
	 *
	 * @return the display name
	 */
	@Override
	public String getDisplayName() {
		return "Artifacts";
	}

	/**
	 * Gets the url name.
	 *
	 * @return the url name
	 */
	@Override
	public String getUrlName() {
		return "Artifacts";
	}

}
