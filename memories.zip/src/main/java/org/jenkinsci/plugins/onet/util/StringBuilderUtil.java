package org.jenkinsci.plugins.onet.util;

import org.apache.commons.lang.StringUtils;

public class StringBuilderUtil {
	
	private StringBuilder stringBuilder;

    public StringBuilderUtil(){
    	stringBuilder = new StringBuilder();
    }

    public void append(String str) {
    	stringBuilder.append(str != null ? str : "");
    }

    public void appendLine(String str) {
    	stringBuilder.append(str != null ? str : "").append(System.getProperty("line.separator"));
    }

    public String toString() {
    	
    	if(stringBuilder.toString().endsWith(System.getProperty("line.separator")))    		
    		return StringUtils.removeEnd(stringBuilder.toString(), System.getProperty("line.separator"));
    	    		
        return stringBuilder.toString();
    }
}
