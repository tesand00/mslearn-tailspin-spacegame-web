package org.jenkinsci.plugins.onet.model;

import java.io.Serializable;

// TODO: Auto-generated Javadoc
/**
 * The Class Runtime.
 */
public class Runtime implements Serializable {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6090884200159305118L;

	/** The host name. */
	private String hostName;
	
	/** The ip. */
	private String IP;
	
	/** The instance. */
	private String instance;
	
	/** The cluster name. */
	private String clusterName;
	
	/** The namespace. */
	private String namespace;
	
	/** The identifier. */
	private String identifier;
	
	/** The image. */
	private String image;

	/**
	 * Gets the host name.
	 *
	 * @return the host name
	 */
	public String getHostName() {
		return hostName;
	}

	/**
	 * Sets the host name.
	 *
	 * @param hostName the new host name
	 */
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	/**
	 * Gets the ip.
	 *
	 * @return the ip
	 */
	public String getIP() {
		return IP;
	}

	/**
	 * Sets the ip.
	 *
	 * @param iP the new ip
	 */
	public void setIP(String iP) {
		IP = iP;
	}

	/**
	 * Gets the single instance of Runtime.
	 *
	 * @return single instance of Runtime
	 */
	public String getInstance() {
		return instance;
	}

	/**
	 * Sets the instance.
	 *
	 * @param instance the new instance
	 */
	public void setInstance(String instance) {
		this.instance = instance;
	}

	/**
	 * Gets the cluster name.
	 *
	 * @return the cluster name
	 */
	public String getClusterName() {
		return clusterName;
	}

	/**
	 * Sets the cluster name.
	 *
	 * @param clusterName the new cluster name
	 */
	public void setClusterName(String clusterName) {
		this.clusterName = clusterName;
	}

	/**
	 * Gets the namespace.
	 *
	 * @return the namespace
	 */
	public String getNamespace() {
		return namespace;
	}

	/**
	 * Sets the namespace.
	 *
	 * @param namespace the new namespace
	 */
	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}	

	/**
	 * Gets the identifier.
	 *
	 * @return the identifier
	 */
	public String getIdentifier() {
		return identifier;
	}

	/**
	 * Sets the identifier.
	 *
	 * @param identifier the new identifier
	 */
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	/**
	 * Gets the image.
	 *
	 * @return the image
	 */
	public String getImage() {
		return image;
	}

	/**
	 * Sets the image.
	 *
	 * @param image the new image
	 */
	public void setImage(String image) {
		this.image = image;
	}	
	
}
