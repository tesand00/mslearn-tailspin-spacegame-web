package org.jenkinsci.plugins.onet.processor;

import java.io.IOException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.jenkinsci.plugins.onet.configuration.OneTConfiguration;
import org.jenkinsci.plugins.onet.constants.OneTConstants;
import org.jenkinsci.plugins.onet.model.Application;
import org.jenkinsci.plugins.onet.model.Body;
import org.jenkinsci.plugins.onet.model.EventData;
import org.jenkinsci.plugins.onet.model.OneTRequest;
import org.jenkinsci.plugins.onet.model.ResponseValue;
import org.jenkinsci.plugins.onet.model.Runtime;
import org.jenkinsci.plugins.onet.model.Transaction;
import org.jenkinsci.plugins.onet.util.CommonUtil;
import org.jenkinsci.plugins.onet.util.StringBuilderUtil;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import hudson.model.Run;
import jenkins.model.Jenkins;


// TODO: Auto-generated Javadoc
/**
 * The Class APIProcessor.
 */
public class APIProcessor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = Logger.getLogger(APIProcessor.class.getName());

	/**
	 * Post event.
	 *
	 * @param req the req
	 * @return the string
	 */
	public String postEvent(OneTRequest req) {

		return postEvent(req, "N/A");
	}

	/**
	 * Record event.
	 *
	 * @param req the req
	 * @param description the description
	 * @return the string
	 */
	public String postEvent(OneTRequest req, String description) {

		ResponseValue responseValue = new ResponseValue();
		StringBuilderUtil stringBuilder = new StringBuilderUtil();

		try {

			if(CommonUtil.checkConfiguration()) {

				boolean successfulPost = false;

				List<String> hostList = Arrays.asList(OneTConfiguration.DESCRIPTOR.host.split(","));

				Collections.shuffle(hostList);

				for(String host : hostList) {

					if(StringUtils.isNotEmpty(System.getProperty("https.proxyHost")) && StringUtils.isNotEmpty(System.getProperty("https.proxyPort"))) {

						LOGGER.finest("Proxy: System - " + System.getProperty("https.proxyHost") + ":" + System.getProperty("https.proxyPort"));

						try {

							responseValue = postJson(host.split(":")[0],
									Integer.parseInt(host.split(":")[1]),
									System.getProperty("https.proxyHost"),
									Integer.parseInt(System.getProperty("https.proxyPort")),
									OneTConfiguration.DESCRIPTOR.credentialsId,
									OneTConfiguration.DESCRIPTOR.url,
									req);
						}
						catch(Exception e) {

							LOGGER.finest("Proxy: System Failure, trying configuration - " + host.split(":")[0] + ":" + host.split(":")[1]);

							responseValue = postJson(host.split(":")[0],
									Integer.parseInt(host.split(":")[1]),
									OneTConfiguration.DESCRIPTOR.proxyHost.split(":")[0],
									Integer.parseInt(OneTConfiguration.DESCRIPTOR.proxyHost.split(":")[1]),
									OneTConfiguration.DESCRIPTOR.credentialsId,
									OneTConfiguration.DESCRIPTOR.url,
									req);
						}
					}
					else if(StringUtils.isNotEmpty(OneTConfiguration.DESCRIPTOR.proxyHost)) {

						LOGGER.finest("Proxy: Configuration - " + host.split(":")[0] + ":" + host.split(":")[1]);

						responseValue = postJson(host.split(":")[0],
								Integer.parseInt(host.split(":")[1]),
								OneTConfiguration.DESCRIPTOR.proxyHost.split(":")[0],
								Integer.parseInt(OneTConfiguration.DESCRIPTOR.proxyHost.split(":")[1]),
								OneTConfiguration.DESCRIPTOR.credentialsId,
								OneTConfiguration.DESCRIPTOR.url,
								req);
					}
					else {

						LOGGER.finest("Proxy: None");

						responseValue = postJson(host.split(":")[0],
								Integer.parseInt(host.split(":")[1]),
								"NoProxy",
								0,
								OneTConfiguration.DESCRIPTOR.credentialsId,
								OneTConfiguration.DESCRIPTOR.url,
								req);
					}

					if(responseValue.getResponseCode() == 200) {
						stringBuilder.appendLine(OneTConstants.ONET_LOG + String.format(OneTConstants.EVENT_POST_MESSAGE,
																						"Successful",
																						host,
																						responseValue.getResponseCode(), description));
						successfulPost = true;
						break;
					}
					else {
						stringBuilder.appendLine(OneTConstants.ONET_LOG + String.format(OneTConstants.EVENT_POST_MESSAGE,
																						"Unsuccessful",
																						host,
																						responseValue.getResponseCode(), description));
					}
				}

				if(successfulPost == false) {
					stringBuilder.appendLine(OneTConstants.ONET_LOG + BackupProcessor.backupBuild(req));
				}
			}
		}
		catch (Exception e) {
			stringBuilder.appendLine(OneTConstants.ONET_LOG + String.format(OneTConstants.EVENT_POST_MESSAGE,
																			"Unsuccessful",
																			"N/A",
																			responseValue.getResponseCode(), e.toString()));

			stringBuilder.appendLine(OneTConstants.ONET_LOG + BackupProcessor.backupBuild(req));
		}
		finally{
			CommonUtil.nullifyQuietly(req, responseValue);
		}

		return stringBuilder.toString();

	}
	
	public String getIdentifier(Run run) {
		
		if(StringUtils.isNotBlank(CommonUtil.getFolderName(run))) {
			
			ObjectMapper objectMapper = null;
			JsonNode neoJsonNode = null;
			
			try {
				
				objectMapper = new ObjectMapper();	
				
				if(StringUtils.isNotEmpty(System.getProperty("https.proxyHost")) && StringUtils.isNotEmpty(System.getProperty("https.proxyPort"))) {
					
					neoJsonNode = objectMapper.readTree(getJson(OneTConfiguration.DESCRIPTOR.getIdentifierUrl() + "/" + CommonUtil.getFolderName(run), 
																OneTConfiguration.DESCRIPTOR.getIdentifierAuthorizationString(), 
																System.getProperty("https.proxyHost"), 
																Integer.parseInt(System.getProperty("https.proxyPort"))).getContent());
					
					LOGGER.finest("Identifier Proxy: System - " + System.getProperty("https.proxyHost") + ":" + System.getProperty("https.proxyPort"));
					
				}
				else if(StringUtils.isNotEmpty(OneTConfiguration.DESCRIPTOR.getIdentifierProxyHost()) && OneTConfiguration.DESCRIPTOR.getIdentifierProxyPort() > 0) {
					
					neoJsonNode = objectMapper.readTree(getJson(OneTConfiguration.DESCRIPTOR.getIdentifierUrl() + "/" + CommonUtil.getFolderName(run), 
																OneTConfiguration.DESCRIPTOR.getIdentifierAuthorizationString(), 
																OneTConfiguration.DESCRIPTOR.getIdentifierProxyHost(), 
																OneTConfiguration.DESCRIPTOR.getIdentifierProxyPort()).getContent());
					
					LOGGER.finest("Identifier Proxy: Configuration - " + OneTConfiguration.DESCRIPTOR.getIdentifierProxyHost() + ":" + OneTConfiguration.DESCRIPTOR.getIdentifierProxyPort());
					
				}
				else {
					
					neoJsonNode = objectMapper.readTree(getJson(OneTConfiguration.DESCRIPTOR.getIdentifierUrl() + "/" + CommonUtil.getFolderName(run), OneTConfiguration.DESCRIPTOR.getIdentifierAuthorizationString(), "NoProxy", 0).getContent());
					
					LOGGER.finest("Proxy: None");
				}							
				
				if (neoJsonNode != null && neoJsonNode.findValue("attrib").isArray()) {
					
					for (JsonNode jsonNode : neoJsonNode.findValue("attrib")) {
				    	
						if(jsonNode.get("key") != null && jsonNode.get("key").asText().equals("mots"))						
							return jsonNode.get("value").asText();								    	
				    }
			   }			
			}
			catch(Exception e) {
				LOGGER.log(Level.SEVERE,"Exception in APIProcessor.getIdentifier: " + e.getMessage());
			}
			finally {
				
				CommonUtil.nullifyQuietly(objectMapper,
										  neoJsonNode);
				
			}			
		}
		
		return "N/A";		
	}

	/**
	 * Post json.
	 *
	 * @param host the host
	 * @param port the port
	 * @param credentialsId the credentials id
	 * @param url the url
	 * @param request the request
	 * @return the response value
	 */
	public ResponseValue postJson(String host, int port, String proxyHost, int proxyPort, String credentialsId, String url, Object request) {

		ResponseValue responseValue = new ResponseValue();

		HttpHost httpHost = null;
		HttpHost proxyHttpHost = null;
		HttpPost httpPost = null;
		RequestConfig requestConfig = null;
		CloseableHttpClient httpClient = null;
		CloseableHttpResponse response = null;
		ObjectMapper objectMapper = null;
        CredentialsProvider credsProvider = null;
        AuthCache authCache = null;
        BasicScheme basicAuth = null;
        HttpClientContext localContext = null;

    	try	{

    		objectMapper = new ObjectMapper();
        	httpHost = new HttpHost(host, port, "http");
        	credsProvider = new BasicCredentialsProvider();

        	credsProvider.setCredentials(
                    new AuthScope(httpHost.getHostName(), httpHost.getPort()),
                    new UsernamePasswordCredentials(CommonUtil.lookupCredentials(credentialsId).getUsername(),
                    								CommonUtil.lookupCredentials(credentialsId).getPassword().getPlainText()));

        	if(proxyHost.equals("NoProxy")) {

        		requestConfig = RequestConfig.custom()
    				     .setConnectTimeout(OneTConfiguration.DESCRIPTOR.timeout * 1000)
    				     .setConnectionRequestTimeout(OneTConfiguration.DESCRIPTOR.timeout * 1000)
    				     .setSocketTimeout(OneTConfiguration.DESCRIPTOR.timeout * 1000).build();
        	}
        	else {

        		proxyHttpHost = new HttpHost(proxyHost, proxyPort);

        		requestConfig = RequestConfig.custom()
						 .setProxy(proxyHttpHost)
    				     .setConnectTimeout(OneTConfiguration.DESCRIPTOR.timeout * 1000)
    				     .setConnectionRequestTimeout(OneTConfiguration.DESCRIPTOR.timeout * 1000)
    				     .setSocketTimeout(OneTConfiguration.DESCRIPTOR.timeout * 1000).build();
        	}

        	httpClient = HttpClients.custom().setDefaultCredentialsProvider(credsProvider).setDefaultRequestConfig(requestConfig).build();

            authCache = new BasicAuthCache();

            basicAuth = new BasicScheme();
            authCache.put(httpHost, basicAuth);

            localContext = HttpClientContext.create();
            localContext.setAuthCache(authCache);

            httpPost = new HttpPost(url);
            httpPost.setEntity(new StringEntity(objectMapper.writeValueAsString(request)));
            httpPost.setHeader("Content-type", "application/json");

            LOGGER.finest(objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(request));

			response = httpClient.execute(httpHost, httpPost, localContext);

			responseValue = new ResponseValue();

			if(response != null) {
				responseValue.setResponseCode(response.getStatusLine().getStatusCode());

				EntityUtils.consume(response.getEntity());
			}
			else
				responseValue.setResponseCode(404);

		}
    	catch (IOException e) {
    		LOGGER.log(Level.SEVERE,e.getMessage());
		}
    	finally {
    		try	{
    			if(response != null)
            		response.close();

            	if(httpClient != null)
            		httpClient.close();
    		}
    		catch(IOException e) {
    			// Do nothing
    		}

    		CommonUtil.nullifyQuietly(httpHost,
    								  proxyHttpHost,
    								  httpPost,
    								  requestConfig,
    								  httpClient,
    								  response,
    								  objectMapper,
    								  credsProvider,
    								  authCache,
    								  basicAuth,
    								  localContext);
        }

    	return responseValue;
	}
	
	public ResponseValue getJson(String url, String authorizationString, String proxyHost, int proxyPort) {

		ResponseValue responseValue = new ResponseValue();

		HttpGet httpGet = null;
		HttpHost proxyHttpHost = null;		
		HttpEntity entity = null;
		RequestConfig requestConfig = null;
		CloseableHttpClient httpClient = null;
		CloseableHttpResponse response = null;

    	try	{
    		    		
        	if(proxyHost.equals("NoProxy")) {

        		requestConfig = RequestConfig.custom()
    				     .setConnectTimeout(OneTConfiguration.DESCRIPTOR.timeout * 1000)
    				     .setConnectionRequestTimeout(OneTConfiguration.DESCRIPTOR.timeout * 1000)
    				     .setSocketTimeout(OneTConfiguration.DESCRIPTOR.timeout * 1000).build();
        	}
        	else {

        		proxyHttpHost = new HttpHost(proxyHost, proxyPort);

        		requestConfig = RequestConfig.custom()
						 .setProxy(proxyHttpHost)
    				     .setConnectTimeout(OneTConfiguration.DESCRIPTOR.timeout * 1000)
    				     .setConnectionRequestTimeout(OneTConfiguration.DESCRIPTOR.timeout * 1000)
    				     .setSocketTimeout(OneTConfiguration.DESCRIPTOR.timeout * 1000).build();
        	}

        	httpClient = HttpClients.custom().setDefaultRequestConfig(requestConfig).build();
        	        	
            httpGet = new HttpGet(url);            
            httpGet.setHeader("Content-type", "application/json");
            httpGet.setHeader("Authorization", authorizationString);

			response = httpClient.execute(httpGet); 
           							
			responseValue = new ResponseValue();

			if(response != null) {				
				
				responseValue.setResponseCode(response.getStatusLine().getStatusCode());				
				responseValue.setContent(EntityUtils.toString(response.getEntity()));	
			}
			else
				responseValue.setResponseCode(404);

		}
    	catch (IOException e) {
    		LOGGER.log(Level.SEVERE,"Exception in APIProcessor: " + e.getMessage());
		}
    	finally {
    		try	{
    			if(response != null)
            		response.close();

            	if(httpClient != null)
            		httpClient.close();
    		}
    		catch(IOException e) {
    			// Do nothing
    		}

    		CommonUtil.nullifyQuietly(httpGet,
    								  proxyHttpHost,    								  
    								  entity,
    								  requestConfig,
    								  httpClient,
    								  response);
        }

    	return responseValue;
	}

	/**
	 * Initialize one T request.
	 *
	 * @return the one T request
	 */
	public OneTRequest initializeOneTRequest() {

		OneTRequest oneTRequest = new OneTRequest();
		Transaction transaction = new Transaction();
		Runtime runtime = new Runtime();
		Application application = new Application();
		Body body = new Body();
		EventData eventdata = new EventData();


		try {
			runtime.setIP(InetAddress.getLocalHost().getHostAddress());
		}
		catch(UnknownHostException e) {
			LOGGER.log(Level.WARNING, "Unable to set IP address");
			runtime.setIP("");
		}

		try {
			runtime.setHostName(new URL(Jenkins.get().getRootUrl()).getHost());
		}
		catch(MalformedURLException e) {
			LOGGER.log(Level.WARNING, "Unable to set Host");
			runtime.setHostName("");
		}

		runtime.setInstance(Jenkins.get().getRootUrl());
		runtime.setClusterName("");
		runtime.setNamespace("");
		runtime.setImage("");

		application.setDeploymentUnitName("JENKINS");
		application.setMOTSApplicationAcronym("SDT-JENKINS");

		eventdata.setMessageName("JenkinsBuild");
		eventdata.setMessageType("eventdata");

		body.setEventdata(eventdata);

		oneTRequest.setLogType("Trace");
		oneTRequest.setLogLevel("Trace");
		oneTRequest.setLogTimestamp(CommonUtil.getGMTSystemTime());
		oneTRequest.setTransaction(transaction);
		oneTRequest.setRuntime(runtime);
		oneTRequest.setApplication(application);
		oneTRequest.setBody(body);

		return oneTRequest;
	}

}
