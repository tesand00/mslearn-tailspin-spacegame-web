package org.jenkinsci.plugins.onet.plugin;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang.StringUtils;
import org.jenkinsci.plugins.onet.action.ConversationIDAction;
import org.jenkinsci.plugins.onet.configuration.OneTConfiguration;
import org.jenkinsci.plugins.onet.constants.OneTConstants;
import org.jenkinsci.plugins.onet.model.Body;
import org.jenkinsci.plugins.onet.model.EventData;
import org.jenkinsci.plugins.onet.model.FlowNodeData;
import org.jenkinsci.plugins.onet.model.Meta;
import org.jenkinsci.plugins.onet.model.OneTRequest;
import org.jenkinsci.plugins.onet.model.Stage;
import org.jenkinsci.plugins.onet.model.Step;
import org.jenkinsci.plugins.onet.model.Transaction;
import org.jenkinsci.plugins.onet.processor.APIProcessor;
import org.jenkinsci.plugins.onet.util.CommonUtil;
import org.jenkinsci.plugins.workflow.actions.WorkspaceAction;
import org.jenkinsci.plugins.workflow.cps.CpsFlowExecution;
import org.jenkinsci.plugins.workflow.cps.nodes.StepEndNode;
import org.jenkinsci.plugins.workflow.cps.nodes.StepStartNode;
import org.jenkinsci.plugins.workflow.flow.FlowExecutionListener;
import org.jenkinsci.plugins.workflow.flow.GraphListener;
import org.jenkinsci.plugins.workflow.graph.FlowGraphWalker;
import org.jenkinsci.plugins.workflow.graph.FlowNode;

import com.cloudbees.workflow.flownode.FlowNodeUtil;
import com.cloudbees.workflow.rest.external.AtomFlowNodeExt;
import com.cloudbees.workflow.rest.external.StageNodeExt;
import com.fasterxml.jackson.databind.ObjectMapper;

import hudson.Extension;
import hudson.model.Action;
import hudson.model.Job;
import jenkins.model.Jenkins;


// TODO: Auto-generated Javadoc
/**
 * The listener interface for receiving oneTFlowExecution events.
 * The class that is interested in processing a oneTFlowExecution
 * event implements this interface, and the object created
 * with that class is registered with a component using the
 * component's addOneTFlowExecutionListener method. When
 * the oneTFlowExecution event occurs, that object's appropriate
 * method is invoked.
 *
 */
@Extension
public class OneTFlowExecutionListener extends FlowExecutionListener implements GraphListener.Synchronous {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = Logger.getLogger(OneTFlowExecutionListener.class.getName());
		
	/* (non-Javadoc)
	 * @see org.jenkinsci.plugins.workflow.flow.GraphListener#onNewHead(org.jenkinsci.plugins.workflow.graph.FlowNode)
	 */
	@Override
	public void onNewHead(FlowNode flowNode) {	
		
		if(flowNode instanceof StepStartNode && OneTConfiguration.DESCRIPTOR.enabled && OneTConfiguration.DESCRIPTOR.realtime) {
			
			StepStartNode stepStartNode = (StepStartNode)flowNode;
			
			if (stepStartNode.getStepName().equalsIgnoreCase(OneTConstants.STAGE_NODE_TYPE)
	        	    && stepStartNode.getDisplayName().equalsIgnoreCase(OneTConstants.STAGE_NODE_TYPE_START)) {
				
				processFlowNode(stepStartNode, "PipelineStageStart");				
			}
			
		}
				
		if (flowNode instanceof StepEndNode && OneTConfiguration.DESCRIPTOR.enabled && OneTConfiguration.DESCRIPTOR.realtime) {	
			
			StepEndNode stepEndNode = (StepEndNode)flowNode;
						
			if (stepEndNode.getStartNode().getStepName().equalsIgnoreCase(OneTConstants.STAGE_NODE_TYPE)
	        	    && stepEndNode.getDisplayName().equalsIgnoreCase(OneTConstants.STAGE_NODE_TYPE_END)) {
				
				processFlowNode(stepEndNode, "PipelineStageComplete");				
			}		
		}			
	}
	
	/**
	 * Process step end node.
	 *
	 * @param stepEndNode the step end node
	 */
	private void processFlowNode(FlowNode flowNode, String description) {
					
		ObjectMapper objectMapper = new ObjectMapper();
		APIProcessor apiProcessor = new APIProcessor();	
		FlowNodeData flowNodeData = new FlowNodeData();
		List<Stage> stages = new ArrayList<Stage>();
		
		OneTRequest oneTRequest = null;	
		Body body = null;
		Transaction transaction = null;
		EventData eventdata = null;
		Meta meta = null;
		Stage stage = null;
		Step step = null;					
		List<Step> steps = null;
		Job job = null;
		String jobName = null;
		
		List<String> agents = new ArrayList<String>();
		
		List<AtomFlowNodeExt> atomFlowNodeExts = null;
		StageNodeExt stageNodeExt = null;
		AtomFlowNodeExt atomFlowNodeExt = null;
		Iterator<FlowNode> it2 = FlowNodeUtil.getStageNodes(flowNode.getExecution()).iterator();
		
		while (it2.hasNext()) {		
			
			FlowNode stageNode = (FlowNode) it2.next();	
			
		    if(it2.hasNext())
		    	continue;

		    if (flowNode instanceof StepStartNode) {
		       FlowGraphWalker walker = new FlowGraphWalker(flowNode.getExecution());
		       for (FlowNode n : walker) {
		           if (n instanceof StepStartNode) {
		              WorkspaceAction action = n.getAction(WorkspaceAction.class);
		              if (action != null) {
		                 String node = action.getNode().toString();
		                 String workspace = action.getPath().toString();
		                 agents.add(node);
		              }           
		           }
		       }
		    }

			try {				
		
				for (Action action : stageNode.getAllActions()) {		
					
					if (action instanceof com.cloudbees.workflow.rest.endpoints.FlowNodeAPI) { 
						
						try {
							
							oneTRequest = new OneTRequest();
							body = new Body();
							transaction = new Transaction();
							eventdata = new EventData();
							meta = new Meta();
							stage = new Stage();							
							stageNodeExt = (StageNodeExt)((com.cloudbees.workflow.rest.endpoints.FlowNodeAPI) action).doDescribe();
															
							if(stageNodeExt.getError()!=null)
								stage.setErrorMsg(stageNodeExt.getError().getMessage());
							else
								stage.setErrorMsg("");
							
								stage.setStatus(stageNodeExt.getStatus().toString());     	
								stage.setName(stageNodeExt.getName() );
							
							if (stageNodeExt.getDurationMillis() > 0 && stageNodeExt.getDurationMillis() < 360000000)
								stage.setDuration(stageNodeExt.getDurationMillis());
							
							atomFlowNodeExts = ((StageNodeExt)((com.cloudbees.workflow.rest.endpoints.FlowNodeAPI) action).doDescribe()).getStageFlowNodes();	
															
							steps = new ArrayList<Step>();
							
							Iterator<AtomFlowNodeExt> it = atomFlowNodeExts.iterator();
									
							while (it.hasNext()) {
								
								atomFlowNodeExt = (AtomFlowNodeExt) it.next();	
	
								step = new Step();				
								
			                  	if (atomFlowNodeExt.getError() != null) 		                  												
			                  		step.setLog(atomFlowNodeExt.getError().getMessage());				                  						                  						                    	
			                  	else if(atomFlowNodeExt.getParameterDescription() != null)
			                    	step.setLog(atomFlowNodeExt.getParameterDescription());
			                    else 
			                    	step.setLog("");
			                    				                  	
			                  	step.setName(atomFlowNodeExt.getName().toString() );
			                  	step.setStatus(atomFlowNodeExt.getStatus().toString());
		                    	steps.add(step);			                    	
		                    	CommonUtil.nullifyQuietly(step);			                    	
							}
							
							stage.setSteps(steps);
							CommonUtil.nullifyQuietly(step);								
						}
						catch (Exception e) {
							LOGGER.log(Level.SEVERE, "Step Flow Exception " + e.getMessage());
						}
						finally {
							
							stages.add(stage);
							flowNodeData.setStages(stages);
							flowNodeData.setScript(((CpsFlowExecution) flowNode.getExecution()).getScript().toString());
							
							meta.setPipelineData(flowNodeData);
							
						    if ( agents.isEmpty() )
							       agents.add( "n/a");
						    
						    job = FlowNodeUtil.getWorkflowRunForExecution(flowNode.getExecution()).getParent();
						    jobName = job.getFullName();						    
						    
							if(StringUtils.isNotBlank(CommonUtil.decodeString( jobName )))
								meta.setJobName(CommonUtil.decodeString( jobName ));
							
							if(StringUtils.isNotBlank(Jenkins.get().getRootUrl()))
								meta.setInstanceUrl(Jenkins.get().getRootUrl());
							
					        meta.setAgents(agents);
					        meta.setDescription(description);
							
							eventdata.setMessageName(description);
							eventdata.setMessageType("eventdata");
							eventdata.setMeta(meta);
							
							body.setEventdata(eventdata);
							body.setRealtime(OneTConfiguration.DESCRIPTOR.isRealtime());
							
							String timestamp = CommonUtil.getGMTSystemTime();
							
							transaction.setTransactionId(FlowNodeUtil.getWorkflowRunForExecution(flowNode.getExecution()).getAction(ConversationIDAction.class).getID() + "-" + timestamp);
							transaction.setConversationId(FlowNodeUtil.getWorkflowRunForExecution(flowNode.getExecution()).getAction(ConversationIDAction.class).getID());
							transaction.setReceivedTimestamp(timestamp);							
							
							oneTRequest.setLogType("Trace");
							oneTRequest.setLogLevel("Trace");
							oneTRequest.setLogTimestamp(timestamp);
							oneTRequest.setBody(body);
							oneTRequest.setTransaction(transaction);
							
							flowNode.getExecution().getOwner().getListener().getLogger().println(
									apiProcessor.postEvent(oneTRequest, " " + stageNodeExt.getName() + " id: " + transaction.getConversationId()));
														
							CommonUtil.nullifyQuietly(stage,
									                  eventdata,
									                  body,
									                  transaction,
									                  oneTRequest,
									                  agents);								
						}							
					}
				 }
			}
			catch (Exception e) {
					LOGGER.log(Level.SEVERE, "OneTF Exception " + e.getMessage());
			}
			
				CommonUtil.nullifyQuietly(objectMapper,
										  apiProcessor,
										  flowNodeData,
										  stages,
										  stage,
										  eventdata, 
										  meta,
										  body,
										  transaction,
										  steps,
										  oneTRequest,
										  atomFlowNodeExts,
										  stageNodeExt,
										  atomFlowNodeExt,
										  step,
										  agents,
										  job,
										  jobName);	
		}
			
	}
}
