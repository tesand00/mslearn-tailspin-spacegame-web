package org.jenkinsci.plugins.onet.workflow;

import org.jenkinsci.plugins.workflow.cps.CpsScript;
import org.jenkinsci.plugins.workflow.cps.GlobalVariable;

import groovy.lang.Binding;
import hudson.Extension;

// TODO: Auto-generated Javadoc
/**
 * The Class OneTDSL.
 */
@Extension 
public class OneTDSL extends GlobalVariable {

	/* (non-Javadoc)
	 * @see org.jenkinsci.plugins.workflow.cps.GlobalVariable#getName()
	 */
	@Override
	public String getName() {
		
		return "onet";
	}

	/* (non-Javadoc)
	 * @see org.jenkinsci.plugins.workflow.cps.GlobalVariable#getValue(org.jenkinsci.plugins.workflow.cps.CpsScript)
	 */
	@Override
	public Object getValue(CpsScript script) throws Exception {
		
		Binding binding = script.getBinding();
        Object onet;
        
        if (binding.hasVariable(getName())) {
        	onet = binding.getVariable(getName());
        } 
        else {
           
        	onet = script.getClass().getClassLoader().loadClass("org.jenkinsci.plugins.onet.workflow.OneT").getConstructor(CpsScript.class).newInstance(script);
            binding.setVariable(getName(), onet);
        }
        
        return onet;
	}

}
