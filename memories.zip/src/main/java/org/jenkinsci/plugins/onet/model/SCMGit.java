package org.jenkinsci.plugins.onet.model;

import java.util.Collection;
import java.util.List;
import java.util.Set;

import hudson.plugins.git.Branch;

// TODO: Auto-generated Javadoc
/**
 * The Class SCMGit.
 */
public class SCMGit extends SCMBase {
	
	/** The remote urls. */
	private Set<String> remoteUrls;	
	
	/** The branches. */
	private Collection<Branch> branches;

	/**
	 * Gets the remote urls.
	 *
	 * @return the remote urls
	 */
	public Set<String> getRemoteUrls() {
		return remoteUrls;
	}

	/**
	 * Sets the remote urls.
	 *
	 * @param remoteUrls the new remote urls
	 */
	public void setRemoteUrls(Set<String> remoteUrls) {
		this.remoteUrls = remoteUrls;
	}

	/**
	 * Gets the branches.
	 *
	 * @return the branches
	 */
	public Collection<Branch> getBranches() {
		return branches;
	}

	/**
	 * Sets the branches.
	 *
	 * @param branches the new branches
	 */
	public void setBranches(Collection<Branch> branches) {
		this.branches = branches;
	}
}	