package org.jenkinsci.plugins.onet.workflow

import org.jenkinsci.plugins.onet.processor.APIProcessor;
import org.jenkinsci.plugins.onet.model.OneTRequest;
import org.jenkinsci.plugins.onet.constants.OneTConstants;
import com.fasterxml.jackson.databind.ObjectMapper; 

class OneT implements Serializable {

	private org.jenkinsci.plugins.workflow.cps.CpsScript script;

	public OneT(org.jenkinsci.plugins.workflow.cps.CpsScript script) {
		this.script = script;
	}
	
	public String getLogMessage(String message) {
		return OneTConstants.ONET_LOG + message;
	}
   
	public OneTRequest getOneTRequest(){
		APIProcessor apiProcessor = new APIProcessor();             
	    return apiProcessor.initializeOneTRequest();
	}
	
	public String send(OneTRequest req) {		
		APIProcessor apiProcessor = new APIProcessor();
		return apiProcessor.postEvent(req);			        
	}
	
	public String send(OneTRequest req, boolean log) { 
		APIProcessor apiProcessor = new APIProcessor();		
	   	ObjectMapper objectMapper = new ObjectMapper(); 
		return apiProcessor.postEvent(req) + ((log) ? objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(req) : "");		
	}
	
	public String send(Map reqMap){
	   	OneTRequest req = getOneTRequest();
	   	req.getBody().getEventdata().setMeta(reqMap);
	   	return send(req);   
	}  
}