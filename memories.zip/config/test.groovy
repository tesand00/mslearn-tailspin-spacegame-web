import org.jenkinsci.plugins.onet.plugin.OneTConfiguration;

OneTConfiguration.DESCRIPTOR.host = "klsd048.ipcoe.att.com:3904,klsd055.ipcoe.att.com:3904,klsd056.ipcoe.att.com:3904,mlsd095.sfdc.sbc.com:3904,mlsd096.sfdc.sbc.com:3904,mlsd101.sfdc.sbc.com:3904";
OneTConfiguration.DESCRIPTOR.url = "/events/com.att.sdt.dmaap.jenkins.19592-cicd-builds-v1";
OneTConfiguration.DESCRIPTOR.credentialsId = "";
OneTConfiguration.DESCRIPTOR.maxLogSize = 10000;
OneTConfiguration.DESCRIPTOR.maxBackupJobs = 100;
OneTConfiguration.DESCRIPTOR.cron = "0 59 23 * * ?";
OneTConfiguration.DESCRIPTOR.enabled = true;
OneTConfiguration.DESCRIPTOR.mailSMTPHost = "smtp.it.att.com";
OneTConfiguration.DESCRIPTOR.mailTo = "sdt-dmaap-suppt@list.att.com";
OneTConfiguration.DESCRIPTOR.mailFrom = "sdt-dmaap-suppt@list.att.com";
OneTConfiguration.DESCRIPTOR.mailMessage = "Backup was unsuccessful";

OneTConfiguration.DESCRIPTOR.save();