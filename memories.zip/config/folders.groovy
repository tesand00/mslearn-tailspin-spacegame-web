import com.cloudbees.hudson.plugins.folder.Folder
import com.mig82.folders.properties.FolderProperties
import com.mig82.folders.properties.StringProperty

char dollarSign = '\u0024';

Jenkins.instance.getAllItems(com.cloudbees.hudson.plugins.folder.Folder.class).each {	

	if(it.name.contains("com.att")) {
		
		println "Processing folder: " + it.fullName
		
		Map<String,String> values = new HashMap<String,String>();
		
		if(it.getProperties().get(FolderProperties.class) != null) {
			
			for(StringProperty stringProperty : it.getProperties().get(FolderProperties.class).getProperties()) {
				
					values.put(stringProperty.getKey(), stringProperty.getValue());
					println "Existing Property. Key: " + stringProperty.getKey() + " | Value: " + stringProperty.getValue();							
			}			
		}
		
		List<StringProperty> stringProperties = new ArrayList<StringProperty>();
		
		if(!values.containsKey("SB_PIPELINE_NAME")) {
			
			stringProperties.add(new StringProperty("SB_PIPELINE_NAME", String.valueOf(dollarSign) + "JOB_NAME"));
			println "Added SB_PIPELINE_NAME";
		}
		
		if(!values.containsKey("SB_TEAMSPACE")) {
			
			stringProperties.add(new StringProperty("SB_TEAMSPACE", String.valueOf(dollarSign) + "TEAMSPACE"));
			println "Added SB_TEAMSPACE";
		}
		
		if(!values.containsKey("SB_MOTSID")) {
			
			stringProperties.add(new StringProperty("SB_MOTSID", String.valueOf(dollarSign) + "MOTSID"));
			println "Added SB_MOTSID";
		}
		
		if(!stringProperties.isEmpty()) {
			
			if(it.getProperties().get(FolderProperties.class) != null) 
				it.getProperties().get(FolderProperties.class).setProperties(stringProperties.toArray(new StringProperty[stringProperties.size()]));			
			else {
				
				FolderProperties folderProperties = new FolderProperties();
				folderProperties.setProperties(stringProperties.toArray(new StringProperty[stringProperties.size()]));
				((Folder)it).addProperty(folderProperties);
			}
			
			((Folder) it).save();
		}	 	
	}	
};