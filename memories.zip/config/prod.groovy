import com.cloudbees.plugins.credentials.impl.*;
import com.cloudbees.plugins.credentials.*;
import com.cloudbees.plugins.credentials.domains.*;
import org.jenkinsci.plugins.onet.plugin.OneTConfiguration;

Credentials cred = new UsernamePasswordCredentialsImpl(CredentialsScope.GLOBAL, "ONET_BACKEND", "Global OneT Backend Credential", "m09811@sdt.att.com", "")
SystemCredentialsProvider.getInstance().getStore().addCredentials(Domain.global(), cred)

OneTConfiguration.DESCRIPTOR.host = "zlp33016.vci.att.com:3904,zlp33017.vci.att.com:3904,zlp33018.vci.att.com:3904";
OneTConfiguration.DESCRIPTOR.url = "/events/com.att.sdt.onet.19592-cicd-builds-v1";
//OneTConfiguration.DESCRIPTOR.proxyHost = "proxy.conexus.svc.local:3128";
OneTConfiguration.DESCRIPTOR.proxyHost = "";
OneTConfiguration.DESCRIPTOR.credentialsId = "ONET_BACKEND";
OneTConfiguration.DESCRIPTOR.maxLogSize = 200;
OneTConfiguration.DESCRIPTOR.maxBackupJobs = 1000;
OneTConfiguration.DESCRIPTOR.cron = "0 59 23 * * ?";
OneTConfiguration.DESCRIPTOR.realtime = true;
OneTConfiguration.DESCRIPTOR.enabled = true;
OneTConfiguration.DESCRIPTOR.mailSMTPHost = "smtp.it.att.com";
OneTConfiguration.DESCRIPTOR.mailTo = "sdt-dmaap-suppt@list.att.com";
OneTConfiguration.DESCRIPTOR.mailFrom = "sdt-dmaap-suppt@list.att.com";
OneTConfiguration.DESCRIPTOR.mailMessage = "Backup was unsuccessful";

OneTConfiguration.DESCRIPTOR.save();
