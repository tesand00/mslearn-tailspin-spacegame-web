
The OneT Plugin wiki is at the following URL: <https://wiki.web.att.com/display/SDT/OneT-Plugin>

# Changelog

## What's new in 2.0.12 (2022-03-29) 
 - Chatbot with log scanning
 - MOTS ID setting at folder level
 - Namespace pulled from folder name
 
## What's new in 2.0.20 (2023-02-10) 
 - Workspace artifact checksum capture
 
## What's new in 2.0.21 (2023-03-17) 
 - Folder properties capture

 